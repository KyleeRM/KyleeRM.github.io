package com.example.inventoryappfinal;

import android.app.AlertDialog;
import android.content.Context;
import android.telephony.SmsManager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.inventoryappfinal.database.DatabaseHelper;
import com.example.inventoryappfinal.model.InventoryItem;

import java.util.List;

/**
 * RecyclerView Adapter for displaying and managing inventory items in a list.
 * Supports updating and deleting items, and also sends an SMS notification when quantity is low.
 */
public class InventoryAdapter extends RecyclerView.Adapter<InventoryAdapter.ViewHolder> {

    private List<InventoryItem> itemList;       // List of inventory items
    private Context context;                    // Context from the parent activity
    private DatabaseHelper db;                  // Database helper instance
    private boolean smsPermissionGranted = false; // Flag for SMS permission

    /**
     * Constructor to initialize adapter with inventory data.
     *
     * @param itemList List of inventory items to be displayed
     */
    public InventoryAdapter(List<InventoryItem> itemList) {
        this.itemList = itemList;
    }

    /**
     * Setter to allow the main activity to update the SMS permission flag.
     *
     * @param granted true if SMS permission was granted
     */
    public void setSmsPermissionGranted(boolean granted) {
        this.smsPermissionGranted = granted;
    }

    /**
     * Inflates each item layout and creates a ViewHolder.
     */
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        context = parent.getContext();
        db = new DatabaseHelper(context);
        View view = LayoutInflater.from(context).inflate(R.layout.inventory_item_layout, parent, false);
        return new ViewHolder(view);
    }

    /**
     * Binds inventory data to each ViewHolder and sets up update/delete actions.
     */
    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        InventoryItem item = itemList.get(position);
        holder.nameText.setText(item.getName());
        holder.quantityText.setText("Qty: " + item.getQuantity());

        // Sets click listener to update item
        holder.updateButton.setOnClickListener(v -> showUpdateDialog(item, position));

        // Sets click listener to delete item
        holder.deleteButton.setOnClickListener(v -> {
            db.deleteItem(item.getId());
            itemList.remove(position);
            notifyItemRemoved(position);
            Toast.makeText(context, "Item deleted", Toast.LENGTH_SHORT).show();
        });
    }

    /**
     * Displays a dialog to allow the user to update an item's quantity.
     * Also sends SMS if the quantity falls below 5 and permission is granted.
     */
    private void showUpdateDialog(InventoryItem item, int position) {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle("Update Quantity");

        final EditText input = new EditText(context);
        input.setHint("Enter new quantity");
        builder.setView(input);

        builder.setPositiveButton("Update", (dialog, which) -> {
            try {
                int newQuantity = Integer.parseInt(input.getText().toString());

                // Updates in database
                db.updateItem(item.getId(), item.getName(), item.getSku(), item.getLocation(), newQuantity);

                // Updates in adapter
                itemList.get(position).setQuantity(newQuantity);
                notifyItemChanged(position);

                Toast.makeText(context, "Quantity updated", Toast.LENGTH_SHORT).show();

                // Sends SMS if quantity is low and permission granted
                if (smsPermissionGranted && newQuantity < 5) {
                    try {
                        SmsManager sms = SmsManager.getDefault();
                        sms.sendTextMessage("+1234567890", null,
                                "Low stock alert: " + item.getName(), null, null);
                        Log.d("SMS", "SMS sent for low stock item: " + item.getName());
                    } catch (SecurityException e) {
                        Toast.makeText(context, "SMS permission denied", Toast.LENGTH_SHORT).show();
                    }
                }

            } catch (NumberFormatException e) {
                Toast.makeText(context, "Invalid number", Toast.LENGTH_SHORT).show();
            }
        });

        builder.setNegativeButton("Cancel", (dialog, which) -> dialog.dismiss());
        builder.show();
    }

    /**
     * Returns the total number of inventory items.
     */
    @Override
    public int getItemCount() {
        return itemList.size();
    }

    /**
     * ViewHolders inner class that holds the item views for reuse in RecyclerView.
     */
    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView nameText, quantityText;
        ImageButton updateButton, deleteButton;

        public ViewHolder(View itemView) {
            super(itemView);
            nameText = itemView.findViewById(R.id.item_name);
            quantityText = itemView.findViewById(R.id.item_quantity);
            updateButton = itemView.findViewById(R.id.update_button);
            deleteButton = itemView.findViewById(R.id.delete_button);
        }
    }
}
