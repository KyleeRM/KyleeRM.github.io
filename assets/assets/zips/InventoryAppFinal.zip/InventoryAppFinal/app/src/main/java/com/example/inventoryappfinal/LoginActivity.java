package com.example.inventoryappfinal;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.inventoryappfinal.database.DatabaseHelper;

/**
 * LoginActivity handles user authentication and registration
 * for the Inventory App. It allows users to log in or create
 * a new account by interacting with the {@link DatabaseHelper}.
 */
public class LoginActivity extends AppCompatActivity {

    private EditText usernameInput, passwordInput;
    private Button loginBtn, registerBtn;
    private DatabaseHelper db;

/**
 * Initializes the login screen UI and sets up event handlers
 * for the login and register buttons.
 */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // Binds UI components to layout
        usernameInput = findViewById(R.id.username_input);
        passwordInput = findViewById(R.id.password_input);
        loginBtn = findViewById(R.id.login_btn);
        registerBtn = findViewById(R.id.register_btn);

        // Initialize the database helper
        db = new DatabaseHelper(this);

        // Handles login button click
        loginBtn.setOnClickListener(v -> {
            String user = usernameInput.getText().toString();
            String pass = passwordInput.getText().toString();
            if (db.checkUser(user, pass)) {
                // Navigates to main activity on success
                startActivity(new Intent(LoginActivity.this, MainActivity.class));
            } else {
                // Shows failure message
                Toast.makeText(LoginActivity.this, "Login failed", Toast.LENGTH_SHORT).show();
            }
        });

        // Handles register button click
        registerBtn.setOnClickListener(v -> {
            String user = usernameInput.getText().toString();
            String pass = passwordInput.getText().toString();
            if (db.createUser(user, pass)) {
                Toast.makeText(LoginActivity.this, "User registered", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(LoginActivity.this, "Registration failed", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
