package com.example.inventoryappfinal;

import android.Manifest;
import android.app.AlertDialog;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.inventoryappfinal.database.DatabaseHelper;
import com.example.inventoryappfinal.model.InventoryItem;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.List;

/**
 * MainActivity
 *
 * This class is the main entry point of the Inventory App.
 * It displays all of the inventory items stored in the SQLite database,
 * allows users to add new items, and manages SMS permission and alerts.
 */
public class MainActivity extends AppCompatActivity {

    // Request code constant for SMS permission prompt
    private static final int SMS_PERMISSION_REQUEST_CODE = 123;

    // UI components and database objects
    private RecyclerView inventoryRecycler;
    private DatabaseHelper db;
    private List<InventoryItem> itemList;
    private InventoryAdapter adapter;
    private FloatingActionButton fabAddItem;
    private Button btnSmsPermission;

    // Tracks whether SMS permission has been granted by the user
    private boolean smsPermissionGranted = false;

    /**
     * Initializes the activity, sets up the layout, database,
     * RecyclerView adapter, and the button listeners.
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Connects UI elements with XML layout
        inventoryRecycler = findViewById(R.id.inventory_recycler);
        fabAddItem = findViewById(R.id.fab_add_item);
        btnSmsPermission = findViewById(R.id.btn_sms_settings); // Matches XML ID

        // Initializes the database and adapter
        db = new DatabaseHelper(this);
        itemList = new ArrayList<>();
        adapter = new InventoryAdapter(itemList);
        adapter.setSmsPermissionGranted(smsPermissionGranted);

        // Sets up a grid layout with two columns to display the inventory items
        inventoryRecycler.setLayoutManager(new GridLayoutManager(this, 2));
        inventoryRecycler.setAdapter(adapter);

        // Loads existing items from the database
        loadItems();

        // Floating Action Button for adding new inventory items
        fabAddItem.setOnClickListener(v -> showAddItemDialog());

        // Button for SMS permission handling
        btnSmsPermission.setOnClickListener(v -> showSmsPermissionDialog());
    }

    /**
     * Displays a confirmation dialog to ask the user
     * if they would like to grant SMS permissions.
     */
    private void showSmsPermissionDialog() {
        new AlertDialog.Builder(this)
                .setTitle("SMS Notifications")
                .setMessage("Do you give permission to receive SMS messages?")
                .setPositiveButton("Yes, grant SMS permission", (dialog, which) -> requestSmsPermission())
                .setNegativeButton("Return to inventory screen", (dialog, which) -> dialog.dismiss())
                .create()
                .show();
    }

    /**
     * Requests SEND_SMS permission if not already granted.
     * If already granted, sets the flag and notifies the user.
     */
    private void requestSmsPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            // Ask for permission at runtime
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.SEND_SMS},
                    SMS_PERMISSION_REQUEST_CODE);
        } else {
            // Permission is already granted
            smsPermissionGranted = true;
            Toast.makeText(this, "SMS Permission already granted", Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * Handles the result of the permission dialog.
     * Updates the app’s SMS permission status based on user input.
     */
    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == SMS_PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                smsPermissionGranted = true;
                adapter.setSmsPermissionGranted(true); // ADD THIS LINE
                Toast.makeText(this, "SMS Permission Granted", Toast.LENGTH_SHORT).show();
            } else {
                smsPermissionGranted = false;
                adapter.setSmsPermissionGranted(false); // Optional, but good practice
                Toast.makeText(this, "SMS Permission Denied", Toast.LENGTH_SHORT).show();
            }
        }
    }


    /**
     * Reads all of the items from the SQLite database, adds them to the items list,
     * and updates the RecyclerView to display them on screen.
     * If SMS permission is granted, sends alerts for low-stock items.
     */
    private void loadItems() {
        itemList.clear();
        Cursor cursor = db.getAllItems();

        // Ensures the cursor contains valid data
        if (cursor != null && cursor.moveToFirst()) {
            do {
                // Retrieves database column indexes
                int idIndex = cursor.getColumnIndex(DatabaseHelper.COL_ITEM_ID);
                int nameIndex = cursor.getColumnIndex(DatabaseHelper.COL_ITEM_NAME);
                int skuIndex = cursor.getColumnIndex(DatabaseHelper.COL_ITEM_SKU);
                int locationIndex = cursor.getColumnIndex(DatabaseHelper.COL_ITEM_LOCATION);
                int qtyIndex = cursor.getColumnIndex(DatabaseHelper.COL_ITEM_QTY);

                // Validates that columns exist before retrieving values
                if (idIndex != -1 && nameIndex != -1) {
                    String name = cursor.getString(nameIndex);
                    String sku = skuIndex != -1 ? cursor.getString(skuIndex) : "";
                    String location = locationIndex != -1 ? cursor.getString(locationIndex) : "";
                    int quantity = qtyIndex != -1 ? cursor.getInt(qtyIndex) : 0;

                    // Creates InventoryItem object and add it to the list
                    itemList.add(new InventoryItem(cursor.getInt(idIndex), name, sku, location, quantity));

                    // Sends low stock SMS alert if permission is granted
                    if (smsPermissionGranted && quantity < 5) {
                        try {
                            SmsManager sms = SmsManager.getDefault();
                            sms.sendTextMessage("+1234567890", null,
                                    "Low stock alert: " + name, null, null);
                        } catch (SecurityException e) {
                            Toast.makeText(this, "SMS permission denied", Toast.LENGTH_SHORT).show();
                        }
                    }
                }
            } while (cursor.moveToNext());

            cursor.close(); // Prevents memory leaks
        }

        // Notifies the adapter that the dataset has changed to refresh the RecyclerView
        adapter.notifyDataSetChanged();
    }

    /**
     * Displays a custom dialog allowing the user to add a new inventory item.
     * Validates user input and updates the database and RecyclerView.
     */
    private void showAddItemDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        View dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_add_item, null);
        builder.setView(dialogView);

        // Link dialog input fields to variables
        EditText nameInput = dialogView.findViewById(R.id.editTextItemName);
        EditText skuInput = dialogView.findViewById(R.id.editTextItemId);
        EditText locationInput = dialogView.findViewById(R.id.editTextLocation);
        EditText quantityInput = dialogView.findViewById(R.id.editTextQuantity);
        Button addButton = dialogView.findViewById(R.id.buttonAddItem);
        Button cancelButton = dialogView.findViewById(R.id.buttonCancel);

        AlertDialog dialog = builder.create();

        // Sets dialog background safely (prevents null pointer errors)
        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawableResource(R.drawable.dialog_background);
        }

        dialog.show();

        // Add button that adds item to the database and updates the grid
        addButton.setOnClickListener(v -> {
            String name = nameInput.getText().toString().trim();
            String sku = skuInput.getText().toString().trim();
            String location = locationInput.getText().toString().trim();
            String qtyStr = quantityInput.getText().toString().trim();

            // Validates user input fields
            if (name.isEmpty() || sku.isEmpty() || location.isEmpty() || qtyStr.isEmpty()) {
                Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show();
                return;
            }

            try {
                // Converts quantity input and creates item
                int quantity = Integer.parseInt(qtyStr);
                InventoryItem newItem = new InventoryItem(name, sku, location, quantity);
                long newId = db.insertItem(newItem);

                if (newId != -1) {
                    // Successfully added item to database and list
                    newItem.setId((int) newId);
                    itemList.add(newItem);
                    adapter.notifyItemInserted(itemList.size() - 1);
                    inventoryRecycler.smoothScrollToPosition(itemList.size() - 1);
                    Toast.makeText(this, "Item added successfully!", Toast.LENGTH_SHORT).show();
                } else {
                    // Database insertion failed
                    Toast.makeText(this, "Error: Failed to insert item.", Toast.LENGTH_SHORT).show();
                }

                dialog.dismiss();

            } catch (NumberFormatException e) {
                // Handles invalid quantity input
                Toast.makeText(this, "Invalid quantity entered.", Toast.LENGTH_SHORT).show();
            }
        });

        // Cancel button closes the dialog
        cancelButton.setOnClickListener(v -> dialog.dismiss());
    }
}
