package com.example.inventoryappfinal;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

/**
 * Utility class to handle SMS permission checking and requesting.
 * This class abstracts permission logic to keep Activities clean and readable.
 */
public class SMSPermissionManager {

    // Request code used when asking for SMS permission
    private static final int SMS_PERMISSION_CODE = 100;

    /**
     * Checks whether the SEND_SMS permission has been granted.
     *
     * @param activity The activity context used to check permission
     * @return true if permission is granted, false otherwise
     */
    public static boolean checkPermission(Activity activity) {
        return ContextCompat.checkSelfPermission(activity, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED;
    }

    /**
     * Requests the SEND_SMS permission from the user if it has not been granted.
     *
     * @param activity The activity context used to request permission
     */
    public static void requestPermission(Activity activity) {
        if (ContextCompat.checkSelfPermission(activity, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {

            // Trigger permission request dialog
            ActivityCompat.requestPermissions(activity,
                    new String[]{Manifest.permission.SEND_SMS},
                    SMS_PERMISSION_CODE);
        }
    }
}
