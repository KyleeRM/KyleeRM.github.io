package com.example.inventoryappfinal.database;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.content.ContentValues;
import android.database.Cursor;

import com.example.inventoryappfinal.model.InventoryItem;

/**
 * DatabaseHelper manages all interactions with the local SQLite database
 * for the inventory application. It handles table creation, upgrades,
 * and CRUD operations for both user and inventory item data.
 */

public class DatabaseHelper extends SQLiteOpenHelper {

    // Database version and name
    private static final String DATABASE_NAME = "inventoryApp.db";
    private static final int DATABASE_VERSION = 2; // version bumped for schema change

    // Table names
    public static final String TABLE_USERS = "users";
    public static final String TABLE_ITEMS = "items";

    // User table column names
    public static final String COL_USER_ID = "id";
    public static final String COL_USERNAME = "username";
    public static final String COL_PASSWORD = "password";

    // Item table column names
    public static final String COL_ITEM_ID = "id";
    public static final String COL_ITEM_NAME = "name";
    public static final String COL_ITEM_SKU = "sku";
    public static final String COL_ITEM_LOCATION = "location";
    public static final String COL_ITEM_QTY = "quantity";

    // Constructs the database helper and initializes the database instance.

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }


    // Called when the database is first created.
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + TABLE_USERS + " (" +
                COL_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_USERNAME + " TEXT, " +
                COL_PASSWORD + " TEXT)");

        db.execSQL("CREATE TABLE " + TABLE_ITEMS + " (" +
                COL_ITEM_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_ITEM_NAME + " TEXT, " +
                COL_ITEM_SKU + " TEXT, " +
                COL_ITEM_LOCATION + " TEXT, " +
                COL_ITEM_QTY + " INTEGER)");
    }

/**
 * Called when the database version is upgraded.
 * Drops existing tables and recreates them.
 */

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_ITEMS);
        onCreate(db);
    }

    // Verifies if a user exists with the given username and password.

    public boolean checkUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_USERS, null,
                COL_USERNAME + "=? AND " + COL_PASSWORD + "=?",
                new String[]{username, password},
                null, null, null);
        boolean exists = (cursor.getCount() > 0);
        cursor.close();
        return exists;
    }

    // Registers a new user into the database.
    public boolean createUser(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_USERNAME, username);
        values.put(COL_PASSWORD, password);
        long result = db.insert(TABLE_USERS, null, values);
        return result != -1;
    }

    // Inserts a new inventory item into the database.
    public long insertItem(InventoryItem item) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_ITEM_NAME, item.getName());
        values.put(COL_ITEM_SKU, item.getSku());
        values.put(COL_ITEM_LOCATION, item.getLocation());
        values.put(COL_ITEM_QTY, item.getQuantity());
        return db.insert(TABLE_ITEMS, null, values);
    }

    // Updates an existing inventory item by ID.
    public int updateItem(int id, String name, String sku, String location, int quantity) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_ITEM_NAME, name);
        values.put(COL_ITEM_SKU, sku);
        values.put(COL_ITEM_LOCATION, location);
        values.put(COL_ITEM_QTY, quantity);
        return db.update(TABLE_ITEMS, values, COL_ITEM_ID + "=?", new String[]{String.valueOf(id)});
    }

    // Retrieves all inventory items from the database.
    public Cursor getAllItems() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.query(TABLE_ITEMS, null, null, null, null, null, null);
    }

    // Deletes an inventory item by ID.
    public int deleteItem(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete(TABLE_ITEMS, COL_ITEM_ID + "=?", new String[]{String.valueOf(id)});
    }
}
