package com.example.inventoryappfinal.model;

/**
 * Represents a single item in the inventory database.
 * Includes database ID, name, SKU, warehouse location, and quantity.
 */
public class InventoryItem {

    // Unique identifier from the database (auto-incremented primary key)
    private int id;

    // Name of the inventory item (e.g., "Item A")
    private String name;

    // SKU or custom item identifier (e.g., "ABC123")
    private String sku;

    // Warehouse location (e.g., "Aisle 3, Bin 5")
    private String location;

    // Quantity in stock
    private int quantity;

    /**
     * Constructor used when creating a new item (no database ID yet).
     */
    public InventoryItem(String name, String sku, String location, int quantity) {
        this.name = name;
        this.sku = sku;
        this.location = location;
        this.quantity = quantity;
    }

    /**
     * Constructor used when loading an existing item from the database.
     */
    public InventoryItem(int id, String name, String sku, String location, int quantity) {
        this.id = id;
        this.name = name;
        this.sku = sku;
        this.location = location;
        this.quantity = quantity;
    }

    // Getters and setters

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSku() {
        return sku;
    }

    public void setSku(String sku) {
        this.sku = sku;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
}
