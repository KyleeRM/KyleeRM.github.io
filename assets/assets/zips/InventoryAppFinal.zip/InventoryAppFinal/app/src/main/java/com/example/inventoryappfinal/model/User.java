package com.example.inventoryappfinal.model;
/**
 * Represents a user account in the inventory system.
 * <p>
 * This model class stores login credentials, specifically the username and password,
 * and is primarily used during user authentication and account management operations.
 * */
public class User {
    // The unique username of the user account
    private String username;
    //The plaintext password associated with the user account.
    private String password;

    public User(String username, String password) {
        this.username = username;
        this.password = password;
    }

    //Returns the username of the user.
    public String getUsername() {
        return username;
    }

    //Returns the user's password.
    public String getPassword() {
        return password;
    }
}
