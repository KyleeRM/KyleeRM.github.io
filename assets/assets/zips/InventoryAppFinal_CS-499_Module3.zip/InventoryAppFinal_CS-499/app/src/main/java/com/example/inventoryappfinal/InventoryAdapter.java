package com.example.inventoryappfinal;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.pm.PackageManager;
import android.telephony.SmsManager;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.inventoryappfinal.database.DatabaseHelper;
import com.example.inventoryappfinal.model.InventoryItem;
import com.example.inventoryappfinal.util.AppPreferences;

import java.util.List;

/**
 * InventoryAdapter
 *
 * RecyclerView adapter that binds InventoryItem objects to the inventory grid layout.
 *
 * Responsibilities:
 * - Displays each item (name, location, quantity)
 * - Provides "Update quantity" functionality via a dialog
 * - Provides "Delete item" functionality with confirmation dialog
 * - Triggers low-stock SMS alerts when quantity drops below threshold
 *
 * Note:
 * - This adapter uses the DatabaseHelper instance passed in from MainActivity to perform updates/deletes.
 * - SMS sending is gated behind:
 *   (1) app setting enabled, (2) phone number provided, (3) SEND_SMS permission granted,
 *   (4) device SMS (emulators often do not).
 */
public class InventoryAdapter extends RecyclerView.Adapter<InventoryAdapter.ViewHolder> {

    private static final String TAG = "InventoryAdapter";

    /**
     * List displayed by the adapter (backed by data loaded from SQLite).
     */
    private final List<InventoryItem> itemList;

    /**
     * Database helper used to update/delete rows in SQLite.
     */
    private final DatabaseHelper db;

    /**
     * Context from the RecyclerView parent; used for dialogs/toasts/system services.
     */
    private Context context;

    public InventoryAdapter(List<InventoryItem> itemList, DatabaseHelper db) {
        this.itemList = itemList;
        this.db = db;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        /*
         * Capture the parent context once. This will be the Activity context when used
         * from MainActivity, which is important for permission checks and UI dialogs.
         */
        context = parent.getContext();

        // Inflate a single item tile layout for the inventory grid
        View view = LayoutInflater.from(context).inflate(R.layout.inventory_item_layout, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        /*
         * Bind the InventoryItem at the current adapter position to the UI elements.
         */
        InventoryItem item = itemList.get(position);

        holder.nameText.setText(item.getName());
        holder.locationText.setText("Location: " + item.getLocation());
        holder.quantityText.setText("Qty: " + item.getQuantity());

        // Update quantity (dialog)
        holder.updateButton.setOnClickListener(v -> showUpdateDialog(item, position));

        // Delete item (confirmation dialog requirement)
        holder.deleteButton.setOnClickListener(v -> showDeleteConfirmation(item, position));
    }

    /**
     * Shows a confirmation dialog before deleting an item
     */
    private void showDeleteConfirmation(InventoryItem item, int position) {
        new AlertDialog.Builder(context)
                .setTitle("Delete Item")
                .setMessage("Are you sure you want to delete \"" + item.getName() + "\"?")
                .setPositiveButton("Delete", (dialog, which) -> {
                    // Removes from database
                    db.deleteItem(item.getId());

                    // Removes from UI list and notifies RecyclerView
                    itemList.remove(position);
                    notifyItemRemoved(position);

                    Toast.makeText(context, "Item deleted", Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton("Cancel", (dialog, which) -> dialog.dismiss())
                .show();
    }

    /**
     * Shows a dialog that allows the user to update the quantity of an item.
     * After updating, the adapter updates the UI and conditionally sends a low-stock SMS alert.
     */
    private void showUpdateDialog(InventoryItem item, int position) {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle("Update Quantity");

        // Simple input field for new quantity
        final EditText input = new EditText(context);
        input.setHint("Enter new quantity");
        builder.setView(input);

        builder.setPositiveButton("Update", (dialog, which) -> {
            try {
                // Defensive validation: prevents empty strings from parsing
                String raw = input.getText().toString().trim();
                if (raw.isEmpty()) {
                    Toast.makeText(context, "Please enter a quantity.", Toast.LENGTH_SHORT).show();
                    return;
                }

                int newQuantity = Integer.parseInt(raw);

                // Persist change to database
                db.updateItem(item.getId(), item.getName(), item.getSku(), item.getLocation(), newQuantity);

                // Update in-memory list and refresh only this tile
                itemList.get(position).setQuantity(newQuantity);
                notifyItemChanged(position);

                Toast.makeText(context, "Quantity updated", Toast.LENGTH_SHORT).show();

                // Low-stock alert behavior
                maybeSendLowStockSms(item.getName(), newQuantity);

            } catch (NumberFormatException e) {
                Toast.makeText(context, "Invalid number", Toast.LENGTH_SHORT).show();
            }
        });

        builder.setNegativeButton("Cancel", (dialog, which) -> dialog.dismiss());
        builder.show();
    }

    /**
     * Conditionally sends a low-stock SMS alert.
     *
     * Conditions:
     * - User enabled SMS alerts in Settings (stored in AppPreferences)
     * - Quantity falls below threshold (currently < 5)
     * - Phone number is present
     * - SEND_SMS permission is granted
     * - Device appears capable of SMS (emulators often cannot)
     *
     * If the device cannot send SMS (ex: emulator), the method logs a demo message.
     */
    private void maybeSendLowStockSms(String itemName, int quantity) {
        boolean smsEnabled = AppPreferences.isSmsEnabled(context);
        String phone = AppPreferences.getSmsPhoneNumber(context);

        // Only send when enabled and below threshold
        if (!smsEnabled || quantity >= 5) {
            return;
        }

        // Require a destination phone number when SMS alerts are enabled
        if (phone == null || phone.trim().isEmpty()) {
            Toast.makeText(context, "SMS is enabled, but no phone number is set in Settings.", Toast.LENGTH_SHORT).show();
            return;
        }

        /*
         * Sms permission checks generally require an Activity context (for permission UI).
         * In this app, the adapter is created from MainActivity, so this should be true.
         */
        if (!(context instanceof Activity)) {
            Log.w(TAG, "Context is not an Activity; cannot request/check permission UI safely.");
            return;
        }

        Activity activity = (Activity) context;

        // If permission is not granted, do not crash; guide the user instead.
        if (!SMSPermissionManager.hasSendSmsPermission(activity)) {
            Toast.makeText(context, "SMS permission not granted. Request it in Settings.", Toast.LENGTH_SHORT).show();
            return;
        }

        // Check if device can send SMS (emulator typically can't)
        if (!deviceLikelySupportsSms()) {
            String msg = "Low stock alert (demo): would send SMS to " + phone
                    + " for " + itemName + " (Qty " + quantity + ")";
            Log.i(TAG, msg);
            Toast.makeText(context, "Demo mode: device can't send SMS (emulator). Check Logcat.", Toast.LENGTH_LONG).show();
            return;
        }

        String message = "Low stock alert: " + itemName + " (Qty: " + quantity + ")";

        try {
            /*
             * SmsManager is the legacy system API for sending SMS.
             * This requires SEND_SMS permission and a device with telephony capability.
             */
            SmsManager sms = SmsManager.getDefault();
            sms.sendTextMessage(phone, null, message, null, null);

            Log.i(TAG, "SMS sent to " + phone + ": " + message);
            Toast.makeText(context, "Low stock SMS sent.", Toast.LENGTH_SHORT).show();
        } catch (SecurityException e) {
            Log.e(TAG, "SMS SecurityException", e);
            Toast.makeText(context, "SMS permission denied.", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Log.e(TAG, "Failed to send SMS", e);
            Toast.makeText(context, "Failed to send SMS (see Logcat).", Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * Attempts to determine if the current runtime environment likely supports SMS sending.
     *
     * This is a best-effort check:
     * - FEATURE_TELEPHONY indicates the device has telephony hardware
     * - TelephonyManager.getPhoneType() == PHONE_TYPE_NONE commonly occurs on emulators
     *
     * Returns:
     * - true if the device appears to support SMS
     * - false if not supported or if checks fail
     */
    private boolean deviceLikelySupportsSms() {
        try {
            PackageManager pm = context.getPackageManager();
            boolean hasTelephony = pm.hasSystemFeature(PackageManager.FEATURE_TELEPHONY);

            TelephonyManager tm = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
            if (tm == null) {
                return false;
            }

            // On emulator, often no telephony or phone type = NONE
            return hasTelephony && tm.getPhoneType() != TelephonyManager.PHONE_TYPE_NONE;
        } catch (Exception e) {
            Log.w(TAG, "Telephony check failed", e);
            return false;
        }
    }

    @Override
    public int getItemCount() {
        // RecyclerView uses this to determine how many item tiles to display
        return itemList.size();
    }

    /**
     * ViewHolder holds the references to each UI element inside an inventory item tile.
     * This improves RecyclerView performance by avoiding repeated findViewById calls.
     */
    public static class ViewHolder extends RecyclerView.ViewHolder {

        TextView nameText, locationText, quantityText;
        ImageButton updateButton, deleteButton;

        public ViewHolder(View itemView) {
            super(itemView);

            // Bind tile UI components
            nameText = itemView.findViewById(R.id.item_name);
            locationText = itemView.findViewById(R.id.item_location);
            quantityText = itemView.findViewById(R.id.item_quantity);
            updateButton = itemView.findViewById(R.id.update_button);
            deleteButton = itemView.findViewById(R.id.delete_button);
        }
    }
}
