package com.example.inventoryappfinal;

import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.database.Cursor;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.inventoryappfinal.database.DatabaseHelper;
import com.example.inventoryappfinal.model.InventoryItem;
import com.example.inventoryappfinal.util.AppPreferences;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.List;

/**
 * MainActivity
 *
 * This class is the main entry point of the Inventory App after login.
 * It displays all inventory items stored in the SQLite database, allows
 * users to add new items, and provides a button to open the Settings screen.
 */
public class MainActivity extends AppCompatActivity {

    private RecyclerView inventoryRecycler;
    private DatabaseHelper db;
    private List<InventoryItem> itemList;
    private InventoryAdapter adapter;
    private FloatingActionButton fabAddItem;
    private Button btnSettings;

    @Override
    protected void attachBaseContext(Context newBase) {
        /*
         * Apply the user's saved font scale preference before inflating any views.
         * This ensures that the entire screen respects the selected font size.
         */
        float scale = AppPreferences.getFontScale(newBase);

        Configuration config = new Configuration(newBase.getResources().getConfiguration());
        config.fontScale = scale;

        Context scaledContext = newBase.createConfigurationContext(config);
        super.attachBaseContext(scaledContext);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        /*
         * Security/UX: If the user isn't considered logged in, redirect to LoginActivity.
         * This prevents accessing inventory screens via back-stack navigation after logout.
         */
        if (!AppPreferences.isLoggedIn(this)) {
            startActivity(LoginActivity.createIntent(this));
            finish();
            return;
        }

        setContentView(R.layout.activity_main);

        // Bind views from XML
        inventoryRecycler = findViewById(R.id.inventory_recycler);
        fabAddItem = findViewById(R.id.fab_add_item);

        /*
         * This ID was originally used for SMS settings in earlier iterations.
         * We keep the existing ID to avoid breaking layout references.
         */
        btnSettings = findViewById(R.id.btn_sms_settings);

        // Initialize database and in-memory list
        db = new DatabaseHelper(this);
        itemList = new ArrayList<>();

        // Setup the RecyclerView grid and adapter
        adapter = new InventoryAdapter(itemList, db);
        inventoryRecycler.setLayoutManager(new GridLayoutManager(this, 2));
        inventoryRecycler.setAdapter(adapter);

        // Initial load of items from the database
        loadItems();

        // Floating action button opens the "Add Item" dialog
        fabAddItem.setOnClickListener(v -> showAddItemDialog());

        // Settings button opens SettingsActivity
        btnSettings.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, SettingsActivity.class);
            startActivity(intent);
        });
    }

    @Override
    protected void onResume() {
        super.onResume();

        /*
         * When returning from Settings (font scale, SMS settings, etc.), reload
         * the inventory list so the UI reflects any changes.
         */
        loadItems();
        adapter.notifyDataSetChanged();
    }

    /**
     * Loads all items from the database into the in-memory list and refreshes the adapter.
     */
    private void loadItems() {
        itemList.clear();
        Cursor cursor = db.getAllItems();

        if (cursor != null && cursor.moveToFirst()) {
            do {
                // Grab column indices once per row (safe even if schema changes)
                int idIndex = cursor.getColumnIndex(DatabaseHelper.COL_ITEM_ID);
                int nameIndex = cursor.getColumnIndex(DatabaseHelper.COL_ITEM_NAME);
                int skuIndex = cursor.getColumnIndex(DatabaseHelper.COL_ITEM_SKU);
                int locationIndex = cursor.getColumnIndex(DatabaseHelper.COL_ITEM_LOCATION);
                int qtyIndex = cursor.getColumnIndex(DatabaseHelper.COL_ITEM_QTY);

                // Defensive checks in case a column is missing
                if (idIndex != -1 && nameIndex != -1) {
                    String name = cursor.getString(nameIndex);
                    String sku = skuIndex != -1 ? cursor.getString(skuIndex) : "";
                    String location = locationIndex != -1 ? cursor.getString(locationIndex) : "";
                    int quantity = qtyIndex != -1 ? cursor.getInt(qtyIndex) : 0;

                    itemList.add(new InventoryItem(cursor.getInt(idIndex), name, sku, location, quantity));
                }
            } while (cursor.moveToNext());

            cursor.close();
        }

        adapter.notifyDataSetChanged();
    }

    /**
     * Shows the dialog that allows the user to add a new inventory item.
     */
    private void showAddItemDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);

        // Inflate the custom dialog layout (dialog_add_item.xml)
        View dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_add_item, null);
        builder.setView(dialogView);

        // Bind dialog input fields and buttons
        EditText nameInput = dialogView.findViewById(R.id.editTextItemName);
        EditText skuInput = dialogView.findViewById(R.id.editTextItemId);
        EditText locationInput = dialogView.findViewById(R.id.editTextLocation);
        EditText quantityInput = dialogView.findViewById(R.id.editTextQuantity);
        Button addButton = dialogView.findViewById(R.id.buttonAddItem);
        Button cancelButton = dialogView.findViewById(R.id.buttonCancel);

        AlertDialog dialog = builder.create();
        dialog.show();

        addButton.setOnClickListener(v -> {
            // Read and validate inputs
            String name = nameInput.getText().toString().trim();
            String sku = skuInput.getText().toString().trim();
            String location = locationInput.getText().toString().trim();
            String qtyStr = quantityInput.getText().toString().trim();

            if (name.isEmpty() || sku.isEmpty() || location.isEmpty() || qtyStr.isEmpty()) {
                Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show();
                return;
            }

            try {
                int quantity = Integer.parseInt(qtyStr);

                // Create the new item and insert it into the database
                InventoryItem newItem = new InventoryItem(name, sku, location, quantity);
                long newId = db.insertItem(newItem);

                if (newId != -1) {
                    // If insert succeeds, update the list and RecyclerView efficiently
                    newItem.setId((int) newId);
                    itemList.add(newItem);
                    adapter.notifyItemInserted(itemList.size() - 1);
                    inventoryRecycler.smoothScrollToPosition(itemList.size() - 1);
                    Toast.makeText(this, "Item added successfully!", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(this, "Error: Failed to insert item.", Toast.LENGTH_SHORT).show();
                }

                dialog.dismiss();

            } catch (NumberFormatException e) {
                Toast.makeText(this, "Invalid quantity entered.", Toast.LENGTH_SHORT).show();
            }
        });

        cancelButton.setOnClickListener(v -> dialog.dismiss());
    }
}
