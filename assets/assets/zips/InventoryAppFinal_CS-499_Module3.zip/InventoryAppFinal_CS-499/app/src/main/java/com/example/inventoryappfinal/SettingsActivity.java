package com.example.inventoryappfinal;

import android.content.Context;
import android.content.res.Configuration;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.Switch;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.inventoryappfinal.util.AppPreferences;
import com.google.android.material.appbar.AppBarLayout;

/**
 * SettingsActivity
 *
 * Provides a centralized Settings screen for:
 *  - Changing font size (Small/Medium/Large/X-Large)
 *  - Enabling/disabling SMS alerts (app-level setting)
 *  - Saving a preferred phone number for SMS alerts
 *  - Requesting SMS permission and opening system app settings
 *  - Logging out
 *
 * Note:
 *  - Because Android permissions generally cannot be revoked programmatically, the app includes
 *    a shortcut to system App Settings for users to manage permissions directly.
 *  - Font scaling is applied in attachBaseContext() so the UI inflates with the chosen scale.
 */
public class SettingsActivity extends AppCompatActivity {

    /**
     * Request code used to identify the SEND_SMS permission result callback.
     */
    private static final int SMS_PERMISSION_REQUEST_CODE = 123;

    @Override
    protected void attachBaseContext(Context newBase) {
        /*
         * Applies the user's saved font scale preference before inflating views.
         * This ensures the Settings screen text re-sizes consistently.
         */
        float scale = AppPreferences.getFontScale(newBase);

        Configuration config = new Configuration(newBase.getResources().getConfiguration());
        config.fontScale = scale;

        super.attachBaseContext(newBase.createConfigurationContext(config));
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        /*
         * Note: Status bar / toolbar spacing
         *
         * Some layouts can appear "too high" (under the status bar) depending on device/insets.
         * I applied top padding to the AppBarLayout using the status bar inset, rather than
         * padding the Toolbar directly (which can make the back arrow unclickable or misaligned).
         */
        AppBarLayout appBar = findViewById(R.id.settings_appbar);
        ViewCompat.setOnApplyWindowInsetsListener(appBar, (v, insets) -> {
            int topInset = insets.getInsets(WindowInsetsCompat.Type.statusBars()).top;
            v.setPadding(0, topInset, 0, 0);
            return insets;
        });

        /*
         * Toolbar setup:
         * - Adds the title "Settings"
         * - Enables a back arrow
         * - Uses a custom navigation icon (white arrow on purple background)
         */
        Toolbar toolbar = findViewById(R.id.settings_toolbar);
        setSupportActionBar(toolbar);

        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle("Settings");
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        // Force navigation icon and ensure it exits SettingsActivity when tapped
        toolbar.setNavigationIcon(R.drawable.ic_arrow_back_24);
        toolbar.setNavigationOnClickListener(v -> finish());


        // Bind UI elements
        Switch switchSms = findViewById(R.id.switch_sms_enabled);
        EditText editPhone = findViewById(R.id.edit_sms_phone);
        RadioGroup radioFont = findViewById(R.id.radio_font_size);


        // Load saved settings
        switchSms.setChecked(AppPreferences.isSmsEnabled(this));
        editPhone.setText(AppPreferences.getSmsPhoneNumber(this));

        // Initialize radio selection based on saved scale
        float scale = AppPreferences.getFontScale(this);
        if (scale <= 0.90f) {
            radioFont.check(R.id.radio_small);
        } else if (scale >= 1.25f) {
            radioFont.check(R.id.radio_xlarge);
        } else if (scale >= 1.10f) {
            radioFont.check(R.id.radio_large);
        } else {
            radioFont.check(R.id.radio_medium);
        }

        /*
         * Font size change:
         * - Save the scale in SharedPreferences
         * - Call recreate() so the activity re-inflates views at the new scale
         * - Prevent an infinite recreate loop by only recreating if the value changed
         */
        radioFont.setOnCheckedChangeListener((group, checkedId) -> {
            float newScale = 1.0f; // default "Medium"

            if (checkedId == R.id.radio_small) newScale = 0.90f;
            else if (checkedId == R.id.radio_large) newScale = 1.10f;
            else if (checkedId == R.id.radio_xlarge) newScale = 1.25f;

            float current = AppPreferences.getFontScale(this);
            if (Math.abs(current - newScale) < 0.001f) return;

            AppPreferences.setFontScale(this, newScale);
            recreate();
        });

        // Save app-level SMS enabled/disabled setting
        switchSms.setOnCheckedChangeListener((btn, enabled) ->
                AppPreferences.setSmsEnabled(this, enabled));

        /*
         * Save Phone button:
         * Stores the phone number in shared preferences (app-level).
         */
        findViewById(R.id.btn_save_phone).setOnClickListener(v -> {
            String phone = editPhone.getText().toString().trim();

            if (TextUtils.isEmpty(phone)) {
                Toast.makeText(this, "Phone number required", Toast.LENGTH_SHORT).show();
                return;
            }

            AppPreferences.setSmsPhoneNumber(this, phone);
            Toast.makeText(this, "Phone saved", Toast.LENGTH_SHORT).show();
        });

        /*
         * Request SMS permission:
         * Uses the Android runtime permission system for SEND_SMS.
         * The result is handled in onRequestPermissionsResult().
         */
        findViewById(R.id.btn_request_sms_permission).setOnClickListener(v ->
                SMSPermissionManager.requestSendSmsPermission(this, SMS_PERMISSION_REQUEST_CODE));

        /*
         * Opens system App Settings:
         * Allows the user to manage/revoke permissions outside the app,
         * since apps typically cannot revoke permissions programmatically.
         */
        findViewById(R.id.btn_open_app_settings).setOnClickListener(v ->
                SMSPermissionManager.openAppSettings(this));

        /*
         * Logout:
         * - Clears the login state
         * - Starts LoginActivity
         * - finishAffinity() clears the activity back-stack so the user cannot return
         *   to MainActivity by pressing back.
         */
        findViewById(R.id.btn_logout).setOnClickListener(v ->
                new AlertDialog.Builder(this)
                        .setTitle("Log Out")
                        .setMessage("Are you sure you want to log out?")
                        .setPositiveButton("Yes", (d, w) -> {
                            AppPreferences.clearLogin(this);
                            startActivity(LoginActivity.createIntent(this));
                            finishAffinity();
                        })
                        .setNegativeButton("Cancel", null)
                        .show());
    }

    /**
     * Receives the results from the SEND_SMS permission request and provides user feedback.
     */
    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == SMS_PERMISSION_REQUEST_CODE) {
            Toast.makeText(this,
                    SMSPermissionManager.hasSendSmsPermission(this)
                            ? "SMS permission granted"
                            : "SMS permission denied",
                    Toast.LENGTH_SHORT).show();
        }
    }
}
