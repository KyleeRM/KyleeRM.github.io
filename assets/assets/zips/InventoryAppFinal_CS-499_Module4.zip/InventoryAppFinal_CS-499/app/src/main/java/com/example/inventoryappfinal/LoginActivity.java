package com.example.inventoryappfinal;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.inventoryappfinal.database.DatabaseHelper;
import com.example.inventoryappfinal.util.AppPreferences;

/**
 * LoginActivity
 *
 * Handles user authentication (login) and account creation (registration)
 * for the Inventory App.
 *
 * Responsibilities:
 * - Allows a user to log in using stored credentials in SQLite (via DatabaseHelper)
 * - Allows a user to create an account (via DatabaseHelper)
 * - Persist login state for session continuity (via AppPreferences)
 *
 * Note:
 * - This class uses a simple username/password system stored in a local SQLite DB.
 * - Passwords are currently stored in plaintext in this project
 */
public class LoginActivity extends AppCompatActivity {

    // UI references
    private EditText usernameInput;
    private EditText passwordInput;
    private Button loginBtn;
    private Button registerBtn;

    // Database helper used for user verification and registration
    private DatabaseHelper db;

    /**
     * Factory method for creating an Intent that launches LoginActivity and clears
     * the back stack. Useful after logout.
     *
     * @param context Context used to create the Intent
     * @return Intent configured to start LoginActivity as a fresh task
     */
    public static Intent createIntent(Context context) {
        Intent intent = new Intent(context, LoginActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        return intent;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        /*
         * If a user is already logged in, bypass the login screen and go straight
         * to the main inventory dashboard.
         */
        if (AppPreferences.isLoggedIn(this)) {
            startActivity(new Intent(LoginActivity.this, MainActivity.class));
            finish();
            return;
        }

        // Inflate the login screen layout
        setContentView(R.layout.activity_login);

        // Bind UI elements
        usernameInput = findViewById(R.id.username_input);
        passwordInput = findViewById(R.id.password_input);
        loginBtn = findViewById(R.id.login_btn);
        registerBtn = findViewById(R.id.register_btn);

        // Initialize database helper for user operations
        db = new DatabaseHelper(this);

        /*
         * Login flow:
         * - Validate non-empty fields
         * - Check credentials against database
         * - If valid, store login state and open MainActivity
         */
        loginBtn.setOnClickListener(v -> {
            String user = usernameInput.getText().toString().trim();
            String pass = passwordInput.getText().toString().trim();

            // Basic validation: user must provide both fields
            if (user.isEmpty() || pass.isEmpty()) {
                Toast.makeText(LoginActivity.this,
                        "Please enter a username and password.",
                        Toast.LENGTH_SHORT).show();
                return;
            }

            // Verify credentials via database lookup
            if (db.checkUser(user, pass)) {
                // Persist login state so user can stay logged in across app launches
                AppPreferences.setLoggedIn(LoginActivity.this, true, user);

                // Proceed to main dashboard
                startActivity(new Intent(LoginActivity.this, MainActivity.class));
                finish();
            } else {
                Toast.makeText(LoginActivity.this, "Login failed", Toast.LENGTH_SHORT).show();
            }
        });

        /*
         * Registration flow:
         * - Validate non-empty fields
         * - Insert new user record into database
         * - Prompt user to log in
         */
        registerBtn.setOnClickListener(v -> {
            String user = usernameInput.getText().toString().trim();
            String pass = passwordInput.getText().toString().trim();

            // Basic validation: both fields required
            if (user.isEmpty() || pass.isEmpty()) {
                Toast.makeText(LoginActivity.this,
                        "Please enter a username and password.",
                        Toast.LENGTH_SHORT).show();
                return;
            }

            // Create the user in SQLite
            if (db.createUser(user, pass)) {
                Toast.makeText(LoginActivity.this,
                        "User registered. Please log in.",
                        Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(LoginActivity.this, "Registration failed", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
