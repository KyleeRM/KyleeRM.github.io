package com.example.inventoryappfinal.database;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.content.ContentValues;
import android.database.Cursor;

import com.example.inventoryappfinal.model.InventoryItem;

/**
 * DatabaseHelper
 *
 * SQLiteOpenHelper implementation that manages all database interactions for the app.
 *
 * Responsibilities:
 * - Creates tables for users and inventory items
 * - Handles database upgrades (schema changes)
 * - Provides CRUD operations for:
 *   - User accounts (registration + login verification)
 *   - Inventory items (create/read/update/delete)
 *
 * Notes:
 * - This app stores username/password credentials in a local SQLite database.
 * - Passwords are stored in plaintext for simplicity.
 */
public class DatabaseHelper extends SQLiteOpenHelper {

    // -------------------------
    // Database metadata
    // -------------------------

    private static final String DATABASE_NAME = "inventoryApp.db";
    private static final int DATABASE_VERSION = 2; // version bumped for schema change

    // -------------------------
    // Table names
    // -------------------------

    public static final String TABLE_USERS = "users";
    public static final String TABLE_ITEMS = "items";

    // -------------------------
    // User table columns
    // -------------------------

    public static final String COL_USER_ID = "id";
    public static final String COL_USERNAME = "username";
    public static final String COL_PASSWORD = "password";

    // -------------------------
    // Item table columns
    // -------------------------

    public static final String COL_ITEM_ID = "id";
    public static final String COL_ITEM_NAME = "name";
    public static final String COL_ITEM_SKU = "sku";
    public static final String COL_ITEM_LOCATION = "location";
    public static final String COL_ITEM_QTY = "quantity";

    /**
     * Constructs the helper and initializes SQLiteOpenHelper.
     *
     * @param context app context used to open/create the database file
     */
    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    /**
     * Called automatically the first time the database is created.
     * Creates all required tables for this app.
     *
     * @param db SQLiteDatabase instance provided by the framework
     */
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + TABLE_USERS + " (" +
                COL_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_USERNAME + " TEXT, " +
                COL_PASSWORD + " TEXT)");

        db.execSQL("CREATE TABLE " + TABLE_ITEMS + " (" +
                COL_ITEM_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_ITEM_NAME + " TEXT, " +
                COL_ITEM_SKU + " TEXT, " +
                COL_ITEM_LOCATION + " TEXT, " +
                COL_ITEM_QTY + " INTEGER)");
    }

    /**
     * Called when DATABASE_VERSION is incremented.
     * Current strategy:
     * - Drop existing tables and recreate them.
     *
     * @param db SQLiteDatabase instance
     * @param oldVersion previously installed version
     * @param newVersion new version after upgrade
     */
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_ITEMS);
        onCreate(db);
    }

    /**
     * Verifies whether a user exists with the provided username and password.
     *
     * @param username username to verify
     * @param password password to verify
     * @return true if credentials match a row in the users table; otherwise false
     */
    public boolean checkUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.query(
                TABLE_USERS,
                null,
                COL_USERNAME + "=? AND " + COL_PASSWORD + "=?",
                new String[]{username, password},
                null,
                null,
                null
        );

        boolean exists = (cursor.getCount() > 0);
        cursor.close();
        return exists;
    }

    /**
     * Creates a new user record in the database.
     *
     * @param username username for the new account
     * @param password password for the new account (stored in plaintext for this project)
     * @return true if insert succeeded; false otherwise
     */
    public boolean createUser(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(COL_USERNAME, username);
        values.put(COL_PASSWORD, password);

        long result = db.insert(TABLE_USERS, null, values);
        return result != -1;
    }

    /**
     * Checks whether an inventory item already exists with the same name and location.
     *
     * Duplicate rules (Milestone Three):
     * - Compare Name + Location
     * - Case-insensitive match (using LOWER())
     * - Trimming is applied to reduce false differences caused by whitespace
     *
     * Implementation details:
     * - Uses a "SELECT 1 ... LIMIT 1" query for efficiency
     *
     * @param name item name to check
     * @param location item location to check
     * @return true if a matching item exists; false otherwise
     */
    public boolean itemExistsByNameAndLocation(String name, String location) {
        SQLiteDatabase db = this.getReadableDatabase();

        String normalizedName = name == null ? "" : name.trim().toLowerCase();
        String normalizedLocation = location == null ? "" : location.trim().toLowerCase();

        String sql = "SELECT 1 FROM " + TABLE_ITEMS +
                " WHERE LOWER(" + COL_ITEM_NAME + ") = ? AND LOWER(" + COL_ITEM_LOCATION + ") = ?" +
                " LIMIT 1";

        Cursor cursor = db.rawQuery(sql, new String[]{normalizedName, normalizedLocation});

        boolean exists = (cursor != null && cursor.moveToFirst());
        if (cursor != null) {
            cursor.close();
        }

        return exists;
    }

    /**
     * Checks whether an inventory item already exists with the same name anywhere in the database.
     * Used when Name+Location is not a match, but a name-only match may still be relevant.
     *
     * @param name item name to check
     * @return true if an item with the same name exists; false otherwise
     */
    public boolean itemExistsByName(String name) {
        SQLiteDatabase db = this.getReadableDatabase();

        String normalizedName = name == null ? "" : name.trim().toLowerCase();

        String sql = "SELECT 1 FROM " + TABLE_ITEMS +
                " WHERE LOWER(" + COL_ITEM_NAME + ") = ?" +
                " LIMIT 1";

        Cursor cursor = db.rawQuery(sql, new String[]{normalizedName});

        boolean exists = (cursor != null && cursor.moveToFirst());
        if (cursor != null) {
            cursor.close();
        }

        return exists;
    }

    /**
     * Retrieves distinct locations for a given item name (case-insensitive).
     * This supports user-facing duplicate warnings by showing where the item already exists.
     *
     * Notes:
     * - Caller is responsible for closing the returned Cursor.
     *
     * @param name item name to look up
     * @return Cursor containing distinct location values
     */
    public Cursor getDistinctLocationsForName(String name) {
        SQLiteDatabase db = this.getReadableDatabase();

        String normalizedName = name == null ? "" : name.trim().toLowerCase();

        String sql = "SELECT DISTINCT " + COL_ITEM_LOCATION +
                " FROM " + TABLE_ITEMS +
                " WHERE LOWER(" + COL_ITEM_NAME + ") = ?" +
                " ORDER BY " + COL_ITEM_LOCATION + " ASC";

        return db.rawQuery(sql, new String[]{normalizedName});
    }

    /**
     * Inserts a new inventory item into the items table.
     *
     * @param item InventoryItem containing item data
     * @return row ID of inserted item, or -1 if insert fails
     */
    public long insertItem(InventoryItem item) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(COL_ITEM_NAME, item.getName());
        values.put(COL_ITEM_SKU, item.getSku());
        values.put(COL_ITEM_LOCATION, item.getLocation());
        values.put(COL_ITEM_QTY, item.getQuantity());

        return db.insert(TABLE_ITEMS, null, values);
    }

    /**
     * Updates an existing inventory item record by ID.
     *
     * @param id       database item ID (primary key)
     * @param name     updated name
     * @param sku      updated SKU
     * @param location updated location
     * @param quantity updated quantity
     * @return number of rows affected
     */
    public int updateItem(int id, String name, String sku, String location, int quantity) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(COL_ITEM_NAME, name);
        values.put(COL_ITEM_SKU, sku);
        values.put(COL_ITEM_LOCATION, location);
        values.put(COL_ITEM_QTY, quantity);

        return db.update(TABLE_ITEMS, values, COL_ITEM_ID + "=?", new String[]{String.valueOf(id)});
    }

    /**
     * Retrieves all inventory items from the database.
     *
     * Notes:
     * - Caller must close the Cursor when finished
     *
     * @return Cursor over all rows in TABLE_ITEMS
     */
    public Cursor getAllItems() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.query(TABLE_ITEMS, null, null, null, null, null, null);
    }

    /**
     * Deletes an inventory item row by ID.
     *
     * @param id item ID to delete
     * @return number of rows deleted
     */
    public int deleteItem(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete(TABLE_ITEMS, COL_ITEM_ID + "=?", new String[]{String.valueOf(id)});
    }
}
