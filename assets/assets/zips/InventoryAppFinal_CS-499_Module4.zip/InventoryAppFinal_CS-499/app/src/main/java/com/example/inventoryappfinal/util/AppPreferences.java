package com.example.inventoryappfinal.util;

import android.content.Context;
import android.content.SharedPreferences;

/**
 * AppPreferences
 *
 * Centralized SharedPreferences helper used to store simple app configuration and state.
 *
 * Stores:
 * - App-wide settings:
 *   - Font scale (applies across screens via attachBaseContext in Activities)
 *
 * - Login state:
 *   - Whether the user is logged in
 *   - The current logged-in username
 *
 * - Per-user settings (key prefix + username):
 *   - SMS alerts enabled/disabled
 *   - Preferred SMS phone number
 *
 * Notes:
 * - This project uses SharedPreferences for lightweight persistence.
 * - Per-user keys allow each account to store its own SMS preferences.
 * - This is not meant to be a secure credential store; it stores basic settings/state only.
 */
public class AppPreferences {

    /**
     * Name for the SharedPreferences file used by this app.
     */
    private static final String PREFS_NAME = "inventory_app_prefs";

    // -------------------------
    // App-wide settings
    // -------------------------

    /**
     * Font scaling is stored app-wide (not per user).
     */
    private static final String KEY_FONT_SCALE = "font_scale";

    // -------------------------
    // Login state
    // -------------------------

    /**
     * Whether the app currently considers a user "logged in".
     */
    private static final String KEY_LOGGED_IN = "logged_in";

    /**
     * The username of the currently logged in user.
     */
    private static final String KEY_LOGGED_IN_USER = "logged_in_user";

    // -------------------------
    // Per-user settings (prefix and username)
    // -------------------------

    /**
     * Keys are stored as PREFIX and username to keep settings separate per account.
     */
    private static final String KEY_SMS_ENABLED_PREFIX = "sms_enabled_";
    private static final String KEY_SMS_PHONE_PREFIX = "sms_phone_";

    // -------------------------
    // Defaults
    // -------------------------

    private static final boolean DEFAULT_SMS_ENABLED = false;
    private static final float DEFAULT_FONT_SCALE = 1.0f;

    private AppPreferences() {
        // Utility class (no instances)
    }

    /**
     * Convenience method for retrieving the SharedPreferences instance.
     */
    private static SharedPreferences prefs(Context context) {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
    }

    // -------------------------
    // Login state
    // -------------------------

    /**
     * Sets the login state and stores the current username.
     *
     * @param context  Context used to access SharedPreferences
     * @param loggedIn Whether the user is logged in
     * @param username The username to store (can be null)
     */
    public static void setLoggedIn(Context context, boolean loggedIn, String username) {
        prefs(context).edit()
                .putBoolean(KEY_LOGGED_IN, loggedIn)
                .putString(KEY_LOGGED_IN_USER, username == null ? "" : username.trim())
                .apply();
    }

    /**
     * Returns true if the app considers a user logged in.
     */
    public static boolean isLoggedIn(Context context) {
        return prefs(context).getBoolean(KEY_LOGGED_IN, false);
    }

    /**
     * Returns the saved username for the current login session.
     */
    public static String getLoggedInUser(Context context) {
        return prefs(context).getString(KEY_LOGGED_IN_USER, "");
    }

    /**
     * Clears the stored login state.
     */
    public static void clearLogin(Context context) {
        prefs(context).edit()
                .putBoolean(KEY_LOGGED_IN, false)
                .putString(KEY_LOGGED_IN_USER, "")
                .apply();
    }

    // -------------------------
    // SMS settings (PER USER)
    // -------------------------

    /**
     * Returns the current username if available; otherwise returns "anonymous".
     * This ensures per-user keys always resolve to a valid suffix.
     */
    private static String currentUserOrAnonymous(Context context) {
        String user = getLoggedInUser(context);
        if (user == null || user.trim().isEmpty()) {
            return "anonymous";
        }
        return user.trim();
    }

    /**
     * Builds the per-user key for SMS enabled.
     */
    private static String smsEnabledKey(Context context) {
        return KEY_SMS_ENABLED_PREFIX + currentUserOrAnonymous(context);
    }

    /**
     * Builds the per-user key for stored SMS phone number.
     */
    private static String smsPhoneKey(Context context) {
        return KEY_SMS_PHONE_PREFIX + currentUserOrAnonymous(context);
    }

    /**
     * Saves whether SMS alerts are enabled for the current user.
     */
    public static void setSmsEnabled(Context context, boolean enabled) {
        prefs(context).edit()
                .putBoolean(smsEnabledKey(context), enabled)
                .apply();
    }

    /**
     * Returns whether SMS alerts are enabled for the current user.
     */
    public static boolean isSmsEnabled(Context context) {
        return prefs(context).getBoolean(smsEnabledKey(context), DEFAULT_SMS_ENABLED);
    }

    /**
     * Saves the preferred SMS phone number for the current user.
     */
    public static void setSmsPhoneNumber(Context context, String phoneNumber) {
        String cleaned = phoneNumber == null ? "" : phoneNumber.trim();
        prefs(context).edit()
                .putString(smsPhoneKey(context), cleaned)
                .apply();
    }

    /**
     * Returns the saved SMS phone number for the current user.
     */
    public static String getSmsPhoneNumber(Context context) {
        return prefs(context).getString(smsPhoneKey(context), "");
    }

    /**
     * Optional helper to clear SMS settings for the current user.
     * Useful if you want SMS settings removed on logout (not required).
     */
    public static void clearSmsForCurrentUser(Context context) {
        prefs(context).edit()
                .remove(smsEnabledKey(context))
                .remove(smsPhoneKey(context))
                .apply();
    }

    // -------------------------
    // Font scale (app-wide)
    // -------------------------

    /**
     * Saves the app-wide font scale.
     */
    public static void setFontScale(Context context, float scale) {
        prefs(context).edit()
                .putFloat(KEY_FONT_SCALE, scale)
                .apply();
    }

    /**
     * Returns the app-wide font scale (default is 1.0 / "Medium").
     */
    public static float getFontScale(Context context) {
        return prefs(context).getFloat(KEY_FONT_SCALE, DEFAULT_FONT_SCALE);
    }
}
