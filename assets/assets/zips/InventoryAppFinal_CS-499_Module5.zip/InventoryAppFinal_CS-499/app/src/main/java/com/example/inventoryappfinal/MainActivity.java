package com.example.inventoryappfinal;

import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.database.Cursor;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.inventoryappfinal.database.DatabaseHelper;
import com.example.inventoryappfinal.model.InventoryItem;
import com.example.inventoryappfinal.util.AppPreferences;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * MainActivity
 *
 * Main inventory dashboard screen shown after login.
 *
 * Core responsibilities:
 * - Load inventory items from the SQLite database
 * - Display items in a RecyclerView grid
 * - Support adding items through a dialog
 * - Provide navigation to Settings
 *
 * Milestone Three enhancements (Algorithms & Data Structures):
 * - Search/filter: filter items by name or location
 * - Sort: apply multiple sort modes (name / quantity)
 * - Duplicate detection: warn users before inserting likely duplicate entries
 */
public class MainActivity extends AppCompatActivity {

    // -------------------------
    // Data / persistence
    // -------------------------

    private RecyclerView inventoryRecycler;
    private DatabaseHelper db;

    /**
     * allItems holds the full data set loaded from SQLite (source of truth in memory).
     */
    private final List<InventoryItem> allItems = new ArrayList<>();

    /**
     * displayItems holds the filtered/sorted list currently shown in the RecyclerView.
     */
    private final List<InventoryItem> displayItems = new ArrayList<>();

    private InventoryAdapter adapter;

    // -------------------------
    // UI elements
    // -------------------------

    private FloatingActionButton fabAddItem;
    private Button btnSettings;

    private EditText searchInput;
    private Button btnSearch;
    private Button btnResetSearch;
    private ImageButton btnSortMenu;

    /**
     * Tracks the currently active sort mode so the UI can display the selected option.
     */
    private SortMode currentSortMode = SortMode.NAME_AZ;

    /**
     * Sorting modes supported by the sort menu.
     */
    private enum SortMode {
        NAME_AZ,
        NAME_ZA,
        QTY_LOW_HIGH,
        QTY_HIGH_LOW
    }

    @Override
    protected void attachBaseContext(Context newBase) {
        /*
         * Apply the user's saved font scale preference before inflating any views.
         * This keeps the UI consistent across activities.
         */
        float scale = AppPreferences.getFontScale(newBase);

        Configuration config = new Configuration(newBase.getResources().getConfiguration());
        config.fontScale = scale;

        Context scaledContext = newBase.createConfigurationContext(config);
        super.attachBaseContext(scaledContext);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        /*
         * Security/UX: If the user is not considered logged in, redirect to LoginActivity.
         * This prevents access via back-stack navigation after logout.
         */
        if (!AppPreferences.isLoggedIn(this)) {
            startActivity(LoginActivity.createIntent(this));
            finish();
            return;
        }

        setContentView(R.layout.activity_main);

        // Bind views from the layout
        inventoryRecycler = findViewById(R.id.inventory_recycler);
        fabAddItem = findViewById(R.id.fab_add_item);
        btnSettings = findViewById(R.id.btn_sms_settings);

        searchInput = findViewById(R.id.edit_search);
        btnSearch = findViewById(R.id.btn_search);
        btnResetSearch = findViewById(R.id.btn_reset_search);
        btnSortMenu = findViewById(R.id.btn_sort_menu);

        // Initialize database helper
        db = new DatabaseHelper(this);

        // Setup RecyclerView grid
        adapter = new InventoryAdapter(displayItems, db);
        inventoryRecycler.setLayoutManager(new GridLayoutManager(this, 2));
        inventoryRecycler.setAdapter(adapter);

        // Load all items, then apply current filter/sort for display
        loadItemsFromDatabase();
        applySearchAndSort();

        // Add item dialog
        fabAddItem.setOnClickListener(v -> showAddItemDialog());

        // Settings screen
        btnSettings.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, SettingsActivity.class);
            startActivity(intent);
        });

        // Explicit Search button
        btnSearch.setOnClickListener(v -> applySearchAndSort());

        /*
         * Allow the keyboard "Search" action to run the same search logic
         * without forcing the user to tap the Search button.
         */
        searchInput.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                applySearchAndSort();
                return true;
            }
            return false;
        });

        // Reset clears query and reloads the full list (with current sort applied)
        btnResetSearch.setOnClickListener(v -> {
            searchInput.setText("");
            applySearchAndSort();
            Toast.makeText(this, "Search reset.", Toast.LENGTH_SHORT).show();
        });

        // Sort menu button opens sorting options
        btnSortMenu.setOnClickListener(v -> showSortOptionsDialog());
    }

    @Override
    protected void onResume() {
        super.onResume();

        /*
         * Reload on resume so updates from Settings or other screens
         * are reflected in the inventory list.
         */
        loadItemsFromDatabase();
        applySearchAndSort();
    }

    /**
     * Loads all inventory items from the database into allItems.
     * This method does not apply any sorting/filtering; display is handled separately.
     */
    private void loadItemsFromDatabase() {
        allItems.clear();

        Cursor cursor = db.getAllItems();
        if (cursor != null && cursor.moveToFirst()) {
            do {
                int idIndex = cursor.getColumnIndex(DatabaseHelper.COL_ITEM_ID);
                int nameIndex = cursor.getColumnIndex(DatabaseHelper.COL_ITEM_NAME);
                int skuIndex = cursor.getColumnIndex(DatabaseHelper.COL_ITEM_SKU);
                int locationIndex = cursor.getColumnIndex(DatabaseHelper.COL_ITEM_LOCATION);
                int qtyIndex = cursor.getColumnIndex(DatabaseHelper.COL_ITEM_QTY);

                // Defensive checks in case a column is missing
                if (idIndex != -1 && nameIndex != -1) {
                    String name = cursor.getString(nameIndex);
                    String sku = skuIndex != -1 ? cursor.getString(skuIndex) : "";
                    String location = locationIndex != -1 ? cursor.getString(locationIndex) : "";
                    int quantity = qtyIndex != -1 ? cursor.getInt(qtyIndex) : 0;

                    allItems.add(new InventoryItem(cursor.getInt(idIndex), name, sku, location, quantity));
                }
            } while (cursor.moveToNext());

            cursor.close();
        }
    }

    /**
     * Applies the current search query (filtering) and then sorts the results
     * based on the currentSortMode.
     *
     * This is the main "view pipeline":
     * - Filter allItems -> displayItems
     * - Sort displayItems
     * - Notify adapter
     */
    private void applySearchAndSort() {
        String query = searchInput.getText().toString().trim().toLowerCase();

        displayItems.clear();

        /*
         * Search algorithm:
         * - If query is empty, show everything
         * - Otherwise, include items where name or location contains the query substring
         */
        if (query.isEmpty()) {
            displayItems.addAll(allItems);
        } else {
            for (InventoryItem item : allItems) {
                String name = item.getName() != null ? item.getName().toLowerCase() : "";
                String location = item.getLocation() != null ? item.getLocation().toLowerCase() : "";

                if (name.contains(query) || location.contains(query)) {
                    displayItems.add(item);
                }
            }
        }

        // Sorting step
        sortDisplayItems();

        // Refresh the RecyclerView
        adapter.notifyDataSetChanged();

        // Optional feedback when the query returns no results
        if (!query.isEmpty() && displayItems.isEmpty()) {
            Toast.makeText(this, "No matching items found.", Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * Sorts displayItems according to the currently selected sort mode.
     * This demonstrates comparator-based sorting with different comparison strategies.
     */
    private void sortDisplayItems() {
        switch (currentSortMode) {
            case NAME_AZ:
                Collections.sort(displayItems, Comparator.comparing(
                        item -> item.getName() == null ? "" : item.getName().toLowerCase()
                ));
                break;

            case NAME_ZA:
                Collections.sort(displayItems, (a, b) -> {
                    String an = a.getName() == null ? "" : a.getName().toLowerCase();
                    String bn = b.getName() == null ? "" : b.getName().toLowerCase();
                    return bn.compareTo(an);
                });
                break;

            case QTY_LOW_HIGH:
                Collections.sort(displayItems, Comparator.comparingInt(InventoryItem::getQuantity));
                break;

            case QTY_HIGH_LOW:
                Collections.sort(displayItems, (a, b) -> Integer.compare(b.getQuantity(), a.getQuantity()));
                break;
        }
    }

    /**
     * Displays the sort options dialog.
     * Uses single-choice selection to indicate the currentSortMode and apply updates immediately.
     */
    private void showSortOptionsDialog() {
        String[] options = new String[]{
                "Name (A–Z)",
                "Name (Z–A)",
                "Quantity (Low → High)",
                "Quantity (High → Low)"
        };

        int checkedItemIndex = getCheckedSortIndex();

        new AlertDialog.Builder(this)
                .setTitle("Sort options")
                .setSingleChoiceItems(options, checkedItemIndex, (dialog, which) -> {
                    setSortModeFromIndex(which);
                    applySearchAndSort();
                })
                .setNeutralButton("Reset Filters", (dialog, which) -> {
                    currentSortMode = SortMode.NAME_AZ;
                    applySearchAndSort();
                    Toast.makeText(this, "Sort reset to default.", Toast.LENGTH_SHORT).show();
                })
                .setPositiveButton("Done", null)
                .setNegativeButton("Cancel", null)
                .show();
    }

    /**
     * Maps the currentSortMode to the correct list index for the dialog.
     */
    private int getCheckedSortIndex() {
        switch (currentSortMode) {
            case NAME_AZ:
                return 0;
            case NAME_ZA:
                return 1;
            case QTY_LOW_HIGH:
                return 2;
            case QTY_HIGH_LOW:
                return 3;
            default:
                return 0;
        }
    }

    /**
     * Converts a selected dialog index into the corresponding SortMode.
     */
    private void setSortModeFromIndex(int index) {
        switch (index) {
            case 0:
                currentSortMode = SortMode.NAME_AZ;
                break;
            case 1:
                currentSortMode = SortMode.NAME_ZA;
                break;
            case 2:
                currentSortMode = SortMode.QTY_LOW_HIGH;
                break;
            case 3:
                currentSortMode = SortMode.QTY_HIGH_LOW;
                break;
            default:
                currentSortMode = SortMode.NAME_AZ;
                break;
        }
    }

    /**
     * Shows the dialog used to add a new inventory item.
     *
     * Duplicate detection behavior:
     * - If name + location exists: warn strongly (exact duplicate)
     * - Else if name exists anywhere: warn and show existing locations
     * - Else: insert normally
     */
    private void showAddItemDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);

        View dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_add_item, null);
        builder.setView(dialogView);

        EditText nameInput = dialogView.findViewById(R.id.editTextItemName);
        EditText skuInput = dialogView.findViewById(R.id.editTextItemId);
        EditText locationInput = dialogView.findViewById(R.id.editTextLocation);
        EditText quantityInput = dialogView.findViewById(R.id.editTextQuantity);
        Button addButton = dialogView.findViewById(R.id.buttonAddItem);
        Button cancelButton = dialogView.findViewById(R.id.buttonCancel);

        AlertDialog dialog = builder.create();
        dialog.show();

        addButton.setOnClickListener(v -> {
            String name = nameInput.getText().toString().trim();
            String sku = skuInput.getText().toString().trim();
            String location = locationInput.getText().toString().trim();
            String qtyStr = quantityInput.getText().toString().trim();

            if (name.isEmpty() || sku.isEmpty() || location.isEmpty() || qtyStr.isEmpty()) {
                Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show();
                return;
            }

            int quantity;
            try {
                quantity = Integer.parseInt(qtyStr);
            } catch (NumberFormatException e) {
                Toast.makeText(this, "Invalid quantity entered.", Toast.LENGTH_SHORT).show();
                return;
            }

            // Duplicate check 1: exact name + location match
            boolean matchesNameAndLocation = db.itemExistsByNameAndLocation(name, location);
            if (matchesNameAndLocation) {
                showDuplicateConfirmationDialog(
                        "Duplicate Item Detected",
                        "An item with this name already exists in this same location.\n\n" +
                                "Name: " + name + "\n" +
                                "Location: " + location + "\n\n" +
                                "Would you like to add it anyway?",
                        name, sku, location, quantity, dialog
                );
                return;
            }

            // Duplicate check 2: name exists somewhere else (different location)
            boolean matchesNameOnly = db.itemExistsByName(name);
            if (matchesNameOnly) {
                String existingLocations = buildLocationListForName(name);

                showDuplicateConfirmationDialog(
                        "Similar Item Detected",
                        "An item with this name already exists in your inventory, but in a different location.\n\n" +
                                "Name: " + name + "\n\n" +
                                "Existing location(s):\n" + existingLocations + "\n\n" +
                                "You are adding it to:\n" + location + "\n\n" +
                                "Would you like to add it anyway?",
                        name, sku, location, quantity, dialog
                );
                return;
            }

            // No duplicates detected; insert normally
            insertNewItem(name, sku, location, quantity);
            Toast.makeText(this, "Item added successfully!", Toast.LENGTH_SHORT).show();
            dialog.dismiss();
        });

        cancelButton.setOnClickListener(v -> dialog.dismiss());
    }

    /**
     * Builds a readable bullet list of locations for a given item name.
     * This is used to make duplicate warnings more informative for the user.
     *
     * @param name item name to look up
     * @return formatted string containing distinct locations for that name
     */
    private String buildLocationListForName(String name) {
        Cursor cursor = db.getDistinctLocationsForName(name);
        if (cursor == null) {
            return "(Unable to load locations)";
        }

        StringBuilder sb = new StringBuilder();
        try {
            int locationIndex = cursor.getColumnIndex(DatabaseHelper.COL_ITEM_LOCATION);

            while (cursor.moveToNext()) {
                String loc = locationIndex != -1 ? cursor.getString(locationIndex) : "";
                if (loc == null || loc.trim().isEmpty()) {
                    loc = "(No location saved)";
                }
                sb.append("• ").append(loc).append("\n");
            }
        } finally {
            cursor.close();
        }

        String result = sb.toString().trim();
        return result.isEmpty() ? "(No locations found)" : result;
    }

    /**
     * Shows a confirmation dialog when a potential duplicate is detected.
     *
     * If the user chooses to proceed, the item is inserted normally.
     */
    private void showDuplicateConfirmationDialog(
            String title,
            String message,
            String name,
            String sku,
            String location,
            int quantity,
            AlertDialog addItemDialog
    ) {
        new AlertDialog.Builder(this)
                .setTitle(title)
                .setMessage(message)
                .setPositiveButton("Add Anyway", (d, which) -> {
                    insertNewItem(name, sku, location, quantity);
                    Toast.makeText(this, "Item added successfully!", Toast.LENGTH_SHORT).show();
                    addItemDialog.dismiss();
                })
                .setNegativeButton("Cancel", (d, which) -> d.dismiss())
                .show();
    }

    /**
     * Inserts an item into SQLite and refreshes the lists in memory.
     *
     * Note:
     * - This method inserts into the database first, then updates allItems
     * - The UI is refreshed through applySearchAndSort() so the current filters/sort remain consistent
     */
    private void insertNewItem(String name, String sku, String location, int quantity) {
        InventoryItem newItem = new InventoryItem(name, sku, location, quantity);
        long newId = db.insertItem(newItem);

        if (newId != -1) {
            newItem.setId((int) newId);
            allItems.add(newItem);
            applySearchAndSort();
        } else {
            Toast.makeText(this, "Error: Failed to insert item.", Toast.LENGTH_SHORT).show();
        }
    }
}
