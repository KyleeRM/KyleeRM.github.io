package com.example.inventoryappfinal;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.provider.Settings;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

/**
 * SMSPermissionManager
 *
 * Utility class that centralizes SMS permission checks and permission-related navigation.
 *
 * Responsibilities:
 * - Check whether SEND_SMS permission is granted at runtime
 * - Request SEND_SMS permission using Android's runtime permission dialog
 * - Open the app's Settings screen so the user can manually manage permissions
 *
 * Notes:
 * - Android apps generally cannot revoke permissions programmatically once granted.
 *   Instead, the application will send the user to system App Settings.
 */
public class SMSPermissionManager {

    private SMSPermissionManager() {
        // Utility class (no instances)
    }

    /**
     * Returns true if SEND_SMS permission is granted for the app.
     */
    public static boolean hasSendSmsPermission(Activity activity) {
        return ContextCompat.checkSelfPermission(activity, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED;
    }

    /**
     * Requests SEND_SMS permission. The result is delivered to the calling Activity's
     * onRequestPermissionsResult().
     *
     * @param activity    The Activity requesting permission
     * @param requestCode App-defined request code to match results
     */
    public static void requestSendSmsPermission(Activity activity, int requestCode) {
        ActivityCompat.requestPermissions(
                activity,
                new String[]{Manifest.permission.SEND_SMS},
                requestCode
        );
    }

    /**
     * Opens the system App Settings page for this application.
     * This is used to allow users to manually grant/revoke permissions.
     */
    public static void openAppSettings(Activity activity) {
        Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
        intent.setData(Uri.fromParts("package", activity.getPackageName(), null));
        activity.startActivity(intent);
    }
}
