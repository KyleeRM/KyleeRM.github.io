package com.example.inventoryappfinal;

import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.Switch;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.inventoryappfinal.database.DatabaseBackupManager;
import com.example.inventoryappfinal.database.DatabaseHelper;
import com.example.inventoryappfinal.util.AppPreferences;
import com.google.android.material.appbar.AppBarLayout;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * SettingsActivity
 *
 * Handles app-level settings and user actions:
 * - SMS settings (enabled flag in preferences, phone number stored encrypted in SQLite)
 * - Font size scaling (stored in preferences)
 * - Backup and restore inventory data (export/import JSON via Storage Access Framework)
 * - Logout
 */
public class SettingsActivity extends AppCompatActivity {

    // Request code used for SEND_SMS permission prompt flow.
    private static final int SMS_PERMISSION_REQUEST_CODE = 123;

    private DatabaseHelper db;
    private DatabaseBackupManager backupManager;

    // Storage Access Framework launchers for export/import actions.
    private ActivityResultLauncher<String> exportLauncher;
    private ActivityResultLauncher<String[]> importLauncher;

    /**
     * Applies font scaling before views inflate.
     * This keeps Settings consistent with the user-selected font size.
     */
    @Override
    protected void attachBaseContext(Context newBase) {
        float scale = AppPreferences.getFontScale(newBase);

        Configuration config = new Configuration(newBase.getResources().getConfiguration());
        config.fontScale = scale;

        super.attachBaseContext(newBase.createConfigurationContext(config));
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        // Database helper and backup manager are used for encrypted settings and inventory export/import.
        db = new DatabaseHelper(this);
        backupManager = new DatabaseBackupManager(this, db);

        // Register SAF callbacks before triggering any export/import flows.
        setupExportImportLaunchers();

        // Adjust app bar padding for status bar insets.
        AppBarLayout appBar = findViewById(R.id.settings_appbar);
        ViewCompat.setOnApplyWindowInsetsListener(appBar, (v, insets) -> {
            int topInset = insets.getInsets(WindowInsetsCompat.Type.statusBars()).top;
            v.setPadding(0, topInset, 0, 0);
            return insets;
        });

        // Toolbar setup and back navigation.
        Toolbar toolbar = findViewById(R.id.settings_toolbar);
        setSupportActionBar(toolbar);

        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle("Settings");
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        toolbar.setNavigationIcon(R.drawable.ic_arrow_back_24);
        toolbar.setNavigationOnClickListener(v -> finish());

        // UI bindings.
        Switch switchSms = findViewById(R.id.switch_sms_enabled);
        EditText editPhone = findViewById(R.id.edit_sms_phone);
        RadioGroup radioFont = findViewById(R.id.radio_font_size);

        // SMS enabled flag is stored in preferences (non-sensitive).
        switchSms.setChecked(AppPreferences.isSmsEnabled(this));

        // SMS phone number is sensitive, so it is stored encrypted in SQLite.
        String savedPhone = db.loadSmsPhoneNumber();
        if (!TextUtils.isEmpty(savedPhone)) {
            editPhone.setText(savedPhone);
        }

        // Initialize radio selection based on stored font scale preference.
        float scale = AppPreferences.getFontScale(this);
        if (scale <= 0.90f) {
            radioFont.check(R.id.radio_small);
        } else if (scale >= 1.25f) {
            radioFont.check(R.id.radio_xlarge);
        } else if (scale >= 1.10f) {
            radioFont.check(R.id.radio_large);
        } else {
            radioFont.check(R.id.radio_medium);
        }

        // Persist font scale and recreate to apply changes.
        radioFont.setOnCheckedChangeListener((group, checkedId) -> {
            float newScale = 1.0f;

            if (checkedId == R.id.radio_small) newScale = 0.90f;
            else if (checkedId == R.id.radio_large) newScale = 1.10f;
            else if (checkedId == R.id.radio_xlarge) newScale = 1.25f;

            float current = AppPreferences.getFontScale(this);
            if (Math.abs(current - newScale) < 0.001f) return;

            AppPreferences.setFontScale(this, newScale);
            recreate();
        });

        // Persist SMS enabled flag immediately when toggled.
        switchSms.setOnCheckedChangeListener((btn, enabled) ->
                AppPreferences.setSmsEnabled(this, enabled));

        // Save phone number using encrypted storage. Validation stays simple and user-facing.
        findViewById(R.id.btn_save_phone).setOnClickListener(v -> {
            String phone = editPhone.getText().toString().trim();

            if (TextUtils.isEmpty(phone)) {
                Toast.makeText(this, "Phone number required", Toast.LENGTH_SHORT).show();
                return;
            }

            boolean ok = db.saveSmsPhoneNumber(phone);
            Toast.makeText(this, ok ? "Phone saved" : "Error saving phone", Toast.LENGTH_SHORT).show();
        });

        // Permission request and settings shortcut buttons.
        findViewById(R.id.btn_request_sms_permission).setOnClickListener(v ->
                SMSPermissionManager.requestSendSmsPermission(this, SMS_PERMISSION_REQUEST_CODE));

        findViewById(R.id.btn_open_app_settings).setOnClickListener(v ->
                SMSPermissionManager.openAppSettings(this));

        // Logout clears login state and returns user to Login screen.
        findViewById(R.id.btn_logout).setOnClickListener(v ->
                new AlertDialog.Builder(this)
                        .setTitle("Log Out")
                        .setMessage("Are you sure you want to log out?")
                        .setPositiveButton("Yes", (d, w) -> {
                            AppPreferences.clearLogin(this);
                            startActivity(LoginActivity.createIntent(this));
                            finishAffinity();
                        })
                        .setNegativeButton("Cancel", null)
                        .show());

        // Inventory backup/restore buttons. (IDs must exist in the layout XML.)
        findViewById(R.id.btn_export_inventory).setOnClickListener(v -> startExport());
        findViewById(R.id.btn_import_inventory).setOnClickListener(v -> startImport());
    }

    /**
     * Registers Storage Access Framework activity result callbacks:
     * - Export uses CreateDocument so user chooses save location and filename.
     * - Import uses OpenDocument so user selects a previously exported JSON file.
     */
    private void setupExportImportLaunchers() {

        exportLauncher = registerForActivityResult(
                new ActivityResultContracts.CreateDocument("application/json"),
                uri -> {
                    if (uri == null) return;

                    try {
                        backupManager.exportItemsToUri(uri);
                        Toast.makeText(this, "Export complete", Toast.LENGTH_SHORT).show();
                    } catch (Exception e) {
                        Toast.makeText(this, "Export failed", Toast.LENGTH_LONG).show();
                    }
                }
        );

        importLauncher = registerForActivityResult(
                new ActivityResultContracts.OpenDocument(),
                uri -> {
                    if (uri == null) return;
                    runImport(uri);
                }
        );
    }

    /**
     * Starts export flow and suggests a timestamped filename to the user.
     */
    private void startExport() {
        String timestamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
        String fileName = "inventory_backup_" + timestamp + ".json";
        exportLauncher.launch(fileName);
    }

    /**
     * Starts import flow for JSON backups.
     */
    private void startImport() {
        importLauncher.launch(new String[]{"application/json"});
    }

    /**
     * Imports a backup and updates the database to match the imported data.
     * This uses replace behavior so the app inventory matches the selected JSON file.
     */
    private void runImport(Uri uri) {
        try {
            backupManager.importItemsFromUri(uri, true);
            Toast.makeText(this, "Import complete", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "Import failed", Toast.LENGTH_LONG).show();
        }
    }

    /**
     * Handles permission result for SEND_SMS.
     * UI feedback is kept simple: granted vs denied.
     */
    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == SMS_PERMISSION_REQUEST_CODE) {
            Toast.makeText(this,
                    SMSPermissionManager.hasSendSmsPermission(this)
                            ? "SMS permission granted"
                            : "SMS permission denied",
                    Toast.LENGTH_SHORT).show();
        }
    }
}