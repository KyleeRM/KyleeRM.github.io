package com.example.inventoryappfinal.database;

import android.content.Context;
import android.net.Uri;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

/**
 * DatabaseBackupManager
 *
 * Exports and imports inventory data (TABLE_ITEMS) using the Storage Access Framework (SAF).
 *
 * SAF:
 * - Lets the user choose where to save the backup (Downloads, Drive, etc.)
 * - Lets the user select a file to restore from
 *
 * Backup format (JSON):
 * - root object contains metadata (schema, exportedAtUtc) and an "items" array
 */
public class DatabaseBackupManager {

    // Use application context to avoid leaking an Activity reference.
    private final Context context;
    // Database helper used to read/write inventory records during export/import.
    private final DatabaseHelper db;

    public DatabaseBackupManager(Context context, DatabaseHelper db) {
        this.context = context.getApplicationContext();
        this.db = db;
    }

    /**
     * Exports current inventory items to the given Uri as pretty-printed JSON.
     *
     * Throws Exception so the caller can display a simple failure message.
     */
    public void exportItemsToUri(Uri uri) throws Exception {
        // Pull all inventory items from SQLite and serialize as JSON array.
        JSONArray items = db.exportItemsAsJsonArray();

        // Root wrapper includes schema version and export timestamp for future-proofing.
        JSONObject root = new JSONObject();
        root.put("schema", 1);
        root.put("exportedAtUtc", System.currentTimeMillis());
        root.put("items", items);

        // Indent for readability
        String json = root.toString(2);

        try (OutputStream os = context.getContentResolver().openOutputStream(uri, "w")) {
            if (os == null) {
                throw new Exception("Unable to open output stream");
            }
            os.write(json.getBytes(StandardCharsets.UTF_8));
            os.flush();
        }
    }

    /**
     * Imports inventory items from the given Uri.
     *
     * replaceExisting:
     * - if true: deletes current items before import
     * - if false: merges and skips duplicates (duplicate logic is enforced in DatabaseHelper)
     */
    public void importItemsFromUri(Uri uri, boolean replaceExisting) throws Exception {
        String json = readAllText(uri);

        JSONObject root = new JSONObject(json);
        JSONArray items = root.getJSONArray("items");

        // DatabaseHelper handles insert rules and transaction safety.
        db.importItemsFromJsonArray(items, replaceExisting);
    }

    /**
     * Reads an entire text file from the provided Uri.
     * Uses UTF-8 so JSON encoding is consistent across export/import.
     */
    private String readAllText(Uri uri) throws Exception {
        StringBuilder sb = new StringBuilder();

        try (InputStream is = context.getContentResolver().openInputStream(uri)) {
            if (is == null) {
                throw new Exception("Unable to open input stream");
            }

            try (BufferedReader br = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8))) {
                String line;
                while ((line = br.readLine()) != null) {
                    sb.append(line).append('\n');
                }
            }
        }

        return sb.toString();
    }
}