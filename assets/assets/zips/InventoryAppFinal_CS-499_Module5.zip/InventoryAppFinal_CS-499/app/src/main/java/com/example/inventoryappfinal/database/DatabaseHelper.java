package com.example.inventoryappfinal.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.text.TextUtils;

import com.example.inventoryappfinal.model.InventoryItem;
import com.example.inventoryappfinal.security.CryptoManager;
import com.example.inventoryappfinal.security.PasswordUtil;

import org.json.JSONArray;
import org.json.JSONObject;

/**
 * DatabaseHelper
 *
 * SQLiteOpenHelper for the Inventory app.
 *
 * Responsibilities:
 * - Creates and upgrades SQLite schema
 * - User authentication storage (salt + hash)
 * - Inventory CRUD
 * - Encrypted app settings storage (example: SMS phone number)
 * - Export/import inventory as JSON
 */
public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "inventoryApp.db";
    private static final int DATABASE_VERSION = 3;

    public static final String TABLE_USERS = "users";
    public static final String TABLE_ITEMS = "items";
    private static final String TABLE_APP_SETTINGS = "app_settings";

    // Users
    public static final String COL_USER_ID = "id";
    public static final String COL_USERNAME = "username";
    private static final String COL_PASSWORD_SALT = "password_salt";
    private static final String COL_PASSWORD_HASH = "password_hash";

    // Items
    public static final String COL_ITEM_ID = "id";
    public static final String COL_ITEM_NAME = "name";
    public static final String COL_ITEM_SKU = "sku";
    public static final String COL_ITEM_LOCATION = "location";
    public static final String COL_ITEM_QTY = "quantity";

    // Settings table
    private static final String COL_SETTING_KEY = "setting_key";
    private static final String COL_SETTING_VALUE = "setting_value";

    // Key for encrypted SMS phone number stored in app_settings.
    private static final String KEY_SMS_PHONE_ENCRYPTED = "sms_phone_encrypted";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    /**
     * Creates initial database schema.
     */
    @Override
    public void onCreate(SQLiteDatabase db) {

        // User table stores username plus PBKDF2 salt/hash (no plaintext passwords).
        db.execSQL("CREATE TABLE " + TABLE_USERS + " ("
                + COL_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COL_USERNAME + " TEXT NOT NULL UNIQUE, "
                + COL_PASSWORD_SALT + " TEXT NOT NULL, "
                + COL_PASSWORD_HASH + " TEXT NOT NULL"
                + ")");

        // Inventory table for app items.
        db.execSQL("CREATE TABLE " + TABLE_ITEMS + " ("
                + COL_ITEM_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COL_ITEM_NAME + " TEXT, "
                + COL_ITEM_SKU + " TEXT, "
                + COL_ITEM_LOCATION + " TEXT, "
                + COL_ITEM_QTY + " INTEGER"
                + ")");

        // App settings table for key/value storage (used for encrypted phone number).
        db.execSQL("CREATE TABLE " + TABLE_APP_SETTINGS + " ("
                + COL_SETTING_KEY + " TEXT PRIMARY KEY, "
                + COL_SETTING_VALUE + " TEXT"
                + ")");

        // Index supports fast lookup for duplicate checks (name + location).
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_items_name_location ON "
                + TABLE_ITEMS + " (" + COL_ITEM_NAME + ", " + COL_ITEM_LOCATION + ")");
    }

    /**
     * Handles schema upgrades between versions.
     */
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        if (oldVersion < 3) {
            try {
                db.execSQL("CREATE TABLE IF NOT EXISTS " + TABLE_APP_SETTINGS + " ("
                        + COL_SETTING_KEY + " TEXT PRIMARY KEY, "
                        + COL_SETTING_VALUE + " TEXT"
                        + ")");
            } catch (SQLException ignored) { }

            // Add columns defensively for devices that may already have an older schema.
            safeAddColumn(db, TABLE_USERS, COL_PASSWORD_SALT, "TEXT");
            safeAddColumn(db, TABLE_USERS, COL_PASSWORD_HASH, "TEXT");
        }

        // Ensure the duplicate-check index exists after upgrades.
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_items_name_location ON "
                + TABLE_ITEMS + " (" + COL_ITEM_NAME + ", " + COL_ITEM_LOCATION + ")");
    }

    /**
     * Adds a column if it does not exist.
     * SQLite throws if the column already exists, so this method intentionally ignores that exception.
     */
    private void safeAddColumn(SQLiteDatabase db, String table, String column, String type) {
        try {
            db.execSQL("ALTER TABLE " + table + " ADD COLUMN " + column + " " + type);
        } catch (SQLException ignored) { }
    }

    // Backward-compatible method name used by older code paths.
    public boolean checkUser(String username, String password) {
        return validateUser(username, password);
    }

    /**
     * Validates a username/password pair using stored PBKDF2 salt/hash.
     * Returns false for any missing values or verification failures.
     */
    public boolean validateUser(String username, String password) {
        if (username == null || password == null) return false;

        SQLiteDatabase db = getReadableDatabase();

        // Only pull the columns needed for verification.
        try (Cursor cursor = db.query(
                TABLE_USERS,
                new String[]{COL_PASSWORD_SALT, COL_PASSWORD_HASH},
                COL_USERNAME + "=?",
                new String[]{username.trim()},
                null, null, null
        )) {
            if (!cursor.moveToFirst()) return false;

            String salt = cursor.getString(cursor.getColumnIndexOrThrow(COL_PASSWORD_SALT));
            String hash = cursor.getString(cursor.getColumnIndexOrThrow(COL_PASSWORD_HASH));

            if (salt == null || salt.trim().isEmpty()) return false;
            if (hash == null || hash.trim().isEmpty()) return false;

            return PasswordUtil.verifyPassword(password, salt, hash);
        }
    }

    /**
     * Creates a user account by generating a salt and PBKDF2 hash.
     * Returns false if inputs are invalid or insert fails.
     */
    public boolean createUser(String username, String password) {
        if (username == null || username.trim().isEmpty()) return false;
        if (password == null || password.trim().isEmpty()) return false;

        // Creates per-user salt and derived key.
        String salt = PasswordUtil.generateSaltBase64();
        String hash = PasswordUtil.hashPasswordBase64(password, salt);

        // Prevents inserting unusable user records.
        if (salt.trim().isEmpty() || hash.trim().isEmpty()) {
            return false;
        }

        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(COL_USERNAME, username.trim());
        values.put(COL_PASSWORD_SALT, salt);
        values.put(COL_PASSWORD_HASH, hash);

        long result = db.insert(TABLE_USERS, null, values);
        return result != -1;
    }

    // -------------------------
    // SMS phone number (encrypted)
    // -------------------------

    /**
     * Encrypts and saves the SMS phone number into app_settings.
     *
     * Returns false if encryption fails and does not overwrite an existing saved phone number.
     */
    public boolean saveSmsPhoneNumber(String phonePlaintext) {
        if (phonePlaintext == null) phonePlaintext = "";
        phonePlaintext = phonePlaintext.trim();

        // Keeps defensive validation even though the UI already enforces required input.
        if (phonePlaintext.isEmpty()) return false;

        // Encrypts before writing to SQLite so plaintext is never stored.
        String encrypted = CryptoManager.encryptToString(phonePlaintext);

        // If encryption fails, CryptoManager returns "".
        // This guard prevents replacing an existing valid value with an empty string.
        if (TextUtils.isEmpty(encrypted)) {
            return false;
        }

        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_SETTING_KEY, KEY_SMS_PHONE_ENCRYPTED);
        values.put(COL_SETTING_VALUE, encrypted);

        // Use replace semantics to keep only one row per setting key.
        long result = db.insertWithOnConflict(
                TABLE_APP_SETTINGS,
                null,
                values,
                SQLiteDatabase.CONFLICT_REPLACE
        );

        return result != -1;
    }

    /**
     * Loads and decrypts the saved SMS phone number.
     * Returns empty string if the setting is not present or cannot be decrypted.
     */
    public String loadSmsPhoneNumber() {
        SQLiteDatabase db = getReadableDatabase();

        try (Cursor cursor = db.query(
                TABLE_APP_SETTINGS,
                new String[]{COL_SETTING_VALUE},
                COL_SETTING_KEY + "=?",
                new String[]{KEY_SMS_PHONE_ENCRYPTED},
                null, null, null
        )) {
            if (!cursor.moveToFirst()) return "";

            String encrypted = cursor.getString(cursor.getColumnIndexOrThrow(COL_SETTING_VALUE));
            if (TextUtils.isEmpty(encrypted)) return "";

            // If decryption fails CryptoManager returns "".
            return CryptoManager.decryptToString(encrypted);
        }
    }

    // -------------------------
    // Duplicate checks
    // -------------------------

    /**
     * Returns true if an item already exists with the same name and location (case-insensitive).
     * Used to prevent duplicates during merge-style imports and item entry validation.
     */
    public boolean itemExistsByNameAndLocation(String name, String location) {
        SQLiteDatabase db = this.getReadableDatabase();

        // Normalize input to support case-insensitive comparisons.
        String normalizedName = name == null ? "" : name.trim().toLowerCase();
        String normalizedLocation = location == null ? "" : location.trim().toLowerCase();

        String sql = "SELECT 1 FROM " + TABLE_ITEMS +
                " WHERE LOWER(" + COL_ITEM_NAME + ") = ? AND LOWER(" + COL_ITEM_LOCATION + ") = ?" +
                " LIMIT 1";

        try (Cursor cursor = db.rawQuery(sql, new String[]{normalizedName, normalizedLocation})) {
            return cursor.moveToFirst();
        }
    }

    /**
     * Returns true if an item exists with the same name (case-insensitive).
     * Helpful for UI flows where a name may map to multiple locations.
     */
    public boolean itemExistsByName(String name) {
        SQLiteDatabase db = this.getReadableDatabase();

        String normalizedName = name == null ? "" : name.trim().toLowerCase();

        String sql = "SELECT 1 FROM " + TABLE_ITEMS +
                " WHERE LOWER(" + COL_ITEM_NAME + ") = ?" +
                " LIMIT 1";

        try (Cursor cursor = db.rawQuery(sql, new String[]{normalizedName})) {
            return cursor.moveToFirst();
        }
    }

    /**
     * Returns a Cursor of distinct locations for a given item name (case-insensitive).
     * Caller is responsible for closing the returned Cursor.
     */
    public Cursor getDistinctLocationsForName(String name) {
        SQLiteDatabase db = this.getReadableDatabase();

        String normalizedName = name == null ? "" : name.trim().toLowerCase();

        String sql = "SELECT DISTINCT " + COL_ITEM_LOCATION +
                " FROM " + TABLE_ITEMS +
                " WHERE LOWER(" + COL_ITEM_NAME + ") = ?" +
                " ORDER BY " + COL_ITEM_LOCATION + " ASC";

        return db.rawQuery(sql, new String[]{normalizedName});
    }

    // -------------------------
    // Inventory CRUD
    // -------------------------

    /**
     * Inserts a new inventory item row.
     * Returns the row id, or -1 if the insert fails.
     */
    public long insertItem(InventoryItem item) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(COL_ITEM_NAME, item.getName());
        values.put(COL_ITEM_SKU, item.getSku());
        values.put(COL_ITEM_LOCATION, item.getLocation());
        values.put(COL_ITEM_QTY, item.getQuantity());

        return db.insert(TABLE_ITEMS, null, values);
    }

    /**
     * Updates an existing inventory item by id.
     * Returns number of rows affected.
     */
    public int updateItem(int id, String name, String sku, String location, int quantity) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(COL_ITEM_NAME, name);
        values.put(COL_ITEM_SKU, sku);
        values.put(COL_ITEM_LOCATION, location);
        values.put(COL_ITEM_QTY, quantity);

        return db.update(TABLE_ITEMS, values, COL_ITEM_ID + "=?", new String[]{String.valueOf(id)});
    }

    /**
     * Returns a Cursor for all inventory items.
     * Caller is responsible for closing the returned Cursor.
     */
    public Cursor getAllItems() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.query(TABLE_ITEMS, null, null, null, null, null, null);
    }

    /**
     * Deletes an inventory item by id.
     * Returns number of rows deleted.
     */
    public int deleteItem(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete(TABLE_ITEMS, COL_ITEM_ID + "=?", new String[]{String.valueOf(id)});
    }

    // -------------------------
    // Export / Import (JSON)
    // -------------------------

    /**
     * Exports inventory items as a JSONArray for backup.
     * This method will only export items; it does not export users or settings.
     */
    public JSONArray exportItemsAsJsonArray() throws Exception {
        JSONArray arr = new JSONArray();

        try (Cursor c = getAllItems()) {
            int idIdx = c.getColumnIndexOrThrow(COL_ITEM_ID);
            int nameIdx = c.getColumnIndexOrThrow(COL_ITEM_NAME);
            int skuIdx = c.getColumnIndexOrThrow(COL_ITEM_SKU);
            int locIdx = c.getColumnIndexOrThrow(COL_ITEM_LOCATION);
            int qtyIdx = c.getColumnIndexOrThrow(COL_ITEM_QTY);

            while (c.moveToNext()) {
                JSONObject obj = new JSONObject();
                obj.put(COL_ITEM_ID, c.getInt(idIdx));
                obj.put(COL_ITEM_NAME, c.getString(nameIdx));

                // Preserve explicit null for SKU to round-trip cleanly in JSON.
                obj.put(COL_ITEM_SKU, c.isNull(skuIdx) ? JSONObject.NULL : c.getString(skuIdx));

                obj.put(COL_ITEM_LOCATION, c.getString(locIdx));
                obj.put(COL_ITEM_QTY, c.getInt(qtyIdx));
                arr.put(obj);
            }
        }

        return arr;
    }

    /**
     * Imports items from a JSONArray.
     *
     * replaceExisting:
     * - if true: clears items table before import
     * - if false: merges and skips duplicates by name + location
     */
    public void importItemsFromJsonArray(JSONArray itemsArray, boolean replaceExisting) throws Exception {
        SQLiteDatabase db = getWritableDatabase();

        // Uses a transaction for performance and to ensure all-or-nothing behavior.
        db.beginTransaction();
        try {
            if (replaceExisting) {
                db.delete(TABLE_ITEMS, null, null);
            }

            for (int i = 0; i < itemsArray.length(); i++) {
                JSONObject obj = itemsArray.getJSONObject(i);

                // Keep parsing resilient with defaults.
                String name = obj.optString(COL_ITEM_NAME, "").trim();
                String location = obj.optString(COL_ITEM_LOCATION, "").trim();
                String sku = obj.isNull(COL_ITEM_SKU) ? "" : obj.optString(COL_ITEM_SKU, "");
                int quantity = obj.optInt(COL_ITEM_QTY, 0);

                // Skips invalid rows.
                if (name.isEmpty() || location.isEmpty()) continue;

                // In merge mode, avoid inserting duplicates.
                if (!replaceExisting && itemExistsByNameLocationRaw(db, name, location)) continue;

                ContentValues values = new ContentValues();
                values.put(COL_ITEM_NAME, name);
                values.put(COL_ITEM_LOCATION, location);
                values.put(COL_ITEM_SKU, sku);
                values.put(COL_ITEM_QTY, quantity);

                db.insert(TABLE_ITEMS, null, values);
            }

            db.setTransactionSuccessful();
        } finally {
            db.endTransaction();
        }
    }

    /**
     * Duplicate check using exact match.
     * Used during import inside the same transaction.
     */
    private boolean itemExistsByNameLocationRaw(SQLiteDatabase db, String name, String location) {
        String sql = "SELECT 1 FROM " + TABLE_ITEMS + " WHERE " + COL_ITEM_NAME + "=? AND " + COL_ITEM_LOCATION + "=? LIMIT 1";
        try (Cursor c = db.rawQuery(sql, new String[]{name, location})) {
            return c.moveToFirst();
        }
    }
}