package com.example.inventoryappfinal.model;

/**
 * InventoryItem
 *
 * Model class representing a single inventory item stored in SQLite.
 *
 * Fields include:
 * - id: database primary key (auto-incremented)
 * - name: item name
 * - sku: item SKU / identifier
 * - location: storage location (warehouse/aisle/bin)
 * - quantity: current stock quantity
 *
 * Note:
 * - Two constructors are provided:
 *   (1) One for new items before insertion (no ID yet)
 *   (2) One for items loaded from the database (ID known)
 */
public class InventoryItem {

    // Unique identifier from the database (auto-incremented primary key)
    private int id;

    // Name of the inventory item (e.g., "Item A")
    private String name;

    // SKU or custom item identifier (e.g., "ABC123")
    private String sku;

    // Warehouse location (e.g., "Aisle 3, Bin 5")
    private String location;

    // Quantity in stock
    private int quantity;

    /**
     * Constructor used when creating a new item before it is saved to the database.
     * The database ID will be assigned after insertion.
     *
     * @param name     item name
     * @param sku      SKU or identifier
     * @param location warehouse/storage location
     * @param quantity initial stock quantity
     */
    public InventoryItem(String name, String sku, String location, int quantity) {
        this.name = name;
        this.sku = sku;
        this.location = location;
        this.quantity = quantity;
    }

    /**
     * Constructor used when loading an item from the database, where ID is known.
     *
     * @param id       database primary key
     * @param name     item name
     * @param sku      SKU or identifier
     * @param location warehouse/storage location
     * @param quantity stock quantity
     */
    public InventoryItem(int id, String name, String sku, String location, int quantity) {
        this.id = id;
        this.name = name;
        this.sku = sku;
        this.location = location;
        this.quantity = quantity;
    }

    // -------------------------
    // Getters and setters
    // -------------------------

    /**
     * @return database ID for this item
     */
    public int getId() {
        return id;
    }

    /**
     * Sets the database ID (usually after insertion).
     *
     * @param id database primary key
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return item name
     */
    public String getName() {
        return name;
    }

    /**
     * @param name updated item name
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * @return SKU / identifier
     */
    public String getSku() {
        return sku;
    }

    /**
     * @param sku updated SKU / identifier
     */
    public void setSku(String sku) {
        this.sku = sku;
    }

    /**
     * @return location string
     */
    public String getLocation() {
        return location;
    }

    /**
     * @param location updated warehouse/storage location
     */
    public void setLocation(String location) {
        this.location = location;
    }

    /**
     * @return stock quantity
     */
    public int getQuantity() {
        return quantity;
    }

    /**
     * @param quantity updated stock quantity
     */
    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
}
