package com.example.inventoryappfinal.model;

/**
 * User
 *
 * Model class representing a user account in the inventory system.
 *
 * This class stores:
 * - username: unique identifier for the account
 * - password: the account password (currently stored as plaintext in this project)
 *
 * Note:
 * - In this project, the User model supports login/registration flows.
 */
public class User {

    // Unique username of the user account
    private final String username;

    // Plaintext password associated with the user account (course demo use)
    private final String password;

    /**
     * Constructs a User model with username and password.
     *
     * @param username account username
     * @param password account password (plaintext in this project)
     */
    public User(String username, String password) {
        this.username = username;
        this.password = password;
    }

    /**
     * @return the username for this account
     */
    public String getUsername() {
        return username;
    }

    /**
     * @return the password for this account (currently plaintext in this project)
     */
    public String getPassword() {
        return password;
    }
}
