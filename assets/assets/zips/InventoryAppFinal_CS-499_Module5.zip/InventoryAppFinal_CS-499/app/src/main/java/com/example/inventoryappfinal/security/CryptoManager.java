package com.example.inventoryappfinal.security;

import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;
import android.util.Log;

import java.nio.charset.StandardCharsets;
import java.security.KeyStore;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

/**
 * CryptoManager
 *
 * Small-string encryption/decryption using Android Keystore with AES/GCM.
 *
 * Notes:
 * - This is intended for locally-stored sensitive values (example: SMS phone number).
 * - Returns empty string on failure so callers can fail gracefully without crashing.
 * - The database layer should avoid overwriting existing values when encryption fails.
 */
public final class CryptoManager {

    private static final String TAG = "CryptoManager";

    // Android Keystore provider name used to store/retrieve the AES key material.
    private static final String ANDROID_KEYSTORE = "AndroidKeyStore";

    // App-scoped key alias. If this alias is deleted/invalidated, previously encrypted data cannot be decrypted.
    private static final String KEY_ALIAS = "InventoryApp_AES_GCM_Key";

    // AES/GCM is an authenticated encryption mode (confidentiality + integrity).
    private static final String TRANSFORMATION = "AES/GCM/NoPadding";

    // Utility class; prevent instantiation.
    private CryptoManager() { }

    /**
     * Encrypts a plaintext string and returns a compact String representation.
     *
     * Output format:
     * - Base64(IV) + ":" + Base64(ciphertext)
     *
     * AES/GCM requires an IV (nonce). The cipher generates a fresh IV for each encryption call.
     * The IV is not secret, but it must be stored alongside the ciphertext for decryption.
     */
    public static String encryptToString(String plaintext) {
        // Normalize null input so callers do not need to pre-check.
        if (plaintext == null) plaintext = "";

        try {
            // Uses the app's Keystore-backed AES key (creates it if missing).
            SecretKey key = getOrCreateKey();

            // Initialize cipher for encryption. The IV is generated automatically on init.
            Cipher cipher = Cipher.getInstance(TRANSFORMATION);
            cipher.init(Cipher.ENCRYPT_MODE, key);

            // Capture the generated IV and encrypt the UTF-8 bytes.
            byte[] iv = cipher.getIV();
            byte[] ciphertext = cipher.doFinal(plaintext.getBytes(StandardCharsets.UTF_8));

            // Persistable format: Base64 encode IV and ciphertext, separated by ":".
            String ivB64 = Base64.encodeToString(iv, Base64.NO_WRAP);
            String ctB64 = Base64.encodeToString(ciphertext, Base64.NO_WRAP);

            return ivB64 + ":" + ctB64;

        } catch (Exception e) {
            // Do not crash the app for an encryption failure.
            // Caller should treat "" as a failure and avoid overwriting existing stored values.
            Log.e(TAG, "encryptToString failed", e);
            return "";
        }
    }

    /**
     * Decrypts an encrypted string produced by encryptToString().
     *
     * If the stored key no longer exists or is invalidated (e.g., Keystore reset, uninstall/reinstall),
     * decryption will fail and this returns an empty string.
     */
    public static String decryptToString(String encrypted) {
        // Empty/blank input means "nothing to decrypt".
        if (encrypted == null || encrypted.trim().isEmpty()) return "";

        try {
            // Expected format is "ivBase64:ciphertextBase64".
            String[] parts = encrypted.split(":");
            if (parts.length != 2) return "";

            // Decode both parts from Base64.
            byte[] iv = Base64.decode(parts[0], Base64.NO_WRAP);
            byte[] ciphertext = Base64.decode(parts[1], Base64.NO_WRAP);

            // Retrieve the same AES key used to encrypt.
            SecretKey key = getOrCreateKey();

            // Initialize cipher for decryption using the IV.
            Cipher cipher = Cipher.getInstance(TRANSFORMATION);
            cipher.init(Cipher.DECRYPT_MODE, key, new GCMParameterSpec(128, iv));

            // Decrypt back to UTF-8 String.
            byte[] plaintext = cipher.doFinal(ciphertext);
            return new String(plaintext, StandardCharsets.UTF_8);

        } catch (Exception e) {
            // Do not crash the app for a decryption failure.
            // Caller should treat "" as "unavailable" and prompt the user to re-enter if needed.
            Log.e(TAG, "decryptToString failed", e);
            return "";
        }
    }

    /**
     * Loads the SecretKey from Android Keystore or creates it if it does not exist yet.
     *
     * The key is stored inside Android Keystore, which helps prevent easy extraction of key material.
     */
    private static SecretKey getOrCreateKey() throws Exception {
        // Open the Android Keystore and load its entries.
        KeyStore ks = KeyStore.getInstance(ANDROID_KEYSTORE);
        ks.load(null);

        // If the alias exists, return the stored key.
        if (ks.containsAlias(KEY_ALIAS)) {
            SecretKey existing = (SecretKey) ks.getKey(KEY_ALIAS, null);
            if (existing != null) return existing;
        }

        // Otherwise create a new AES key under our alias.
        KeyGenerator keyGen = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, ANDROID_KEYSTORE);

        // Configure the key for AES/GCM encryption/decryption.
        KeyGenParameterSpec spec = new KeyGenParameterSpec.Builder(
                KEY_ALIAS,
                KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT
        )
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build();

        keyGen.init(spec);
        return keyGen.generateKey();
    }
}