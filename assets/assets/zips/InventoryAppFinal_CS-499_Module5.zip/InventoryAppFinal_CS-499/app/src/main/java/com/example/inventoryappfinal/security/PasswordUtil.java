package com.example.inventoryappfinal.security;

import android.util.Base64;

import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

/**
 * PasswordUtil
 *
 * Password hashing helpers for local authentication.
 *
 * Design notes:
 * - Uses PBKDF2 with an HMAC PRF.
 * - Manual PBKDF2 implementation (no SecretKeyFactory) to avoid emulator/provider issues.
 * - Prefers HmacSHA256 when available and falls back to HmacSHA1 if needed.
 *
 * Storage format:
 * - Salt is stored as Base64 (random bytes).
 * - Derived key (hash) is stored as Base64.
 */
public final class PasswordUtil {

    // Salt size (bytes). A random unique salt per user prevents rainbow table reuse.
    private static final int SALT_BYTES = 16;

    // PBKDF2 work factor. Higher iterations increases cost of brute-force guessing.
    private static final int ITERATIONS = 120_000;

    // Derived key length in bytes (256-bit output).
    private static final int KEY_LENGTH_BYTES = 32; // 256 bits

    // Utility class; prevent instantiation.
    private PasswordUtil() { }

    /**
     * Generates a cryptographically random salt and returns it Base64-encoded.
     */
    public static String generateSaltBase64() {
        byte[] salt = new byte[SALT_BYTES];
        new SecureRandom().nextBytes(salt);
        return Base64.encodeToString(salt, Base64.NO_WRAP);
    }

    /**
     * Returns a PBKDF2 derived key (Base64) for the given password and Base64 salt.
     *
     * Failure behavior:
     * - Returns empty string so callers can reject account creation/login gracefully.
     */
    public static String hashPasswordBase64(String password, String saltBase64) {
        // Normalize null input to reduce caller burden.
        if (password == null) password = "";
        if (saltBase64 == null) saltBase64 = "";

        try {
            byte[] salt = Base64.decode(saltBase64, Base64.NO_WRAP);

            // Prefer HmacSHA256 for PBKDF2. Fall back if not supported by the runtime/provider.
            byte[] dk;
            try {
                dk = pbkdf2(password.getBytes(StandardCharsets.UTF_8), salt, ITERATIONS, KEY_LENGTH_BYTES, "HmacSHA256");
            } catch (Exception ignored) {
                dk = pbkdf2(password.getBytes(StandardCharsets.UTF_8), salt, ITERATIONS, KEY_LENGTH_BYTES, "HmacSHA1");
            }

            return Base64.encodeToString(dk, Base64.NO_WRAP);

        } catch (Exception e) {
            // Treat any hashing failure as unusable output.
            return "";
        }
    }

    /**
     * Verifies a password by recomputing the PBKDF2 hash and comparing it to the expected hash.
     *
     * Uses a constant-time compare to reduce timing side-channels.
     */
    public static boolean verifyPassword(String password, String saltBase64, String expectedHashBase64) {
        if (expectedHashBase64 == null || expectedHashBase64.trim().isEmpty()) return false;

        String computed = hashPasswordBase64(password, saltBase64);
        return constantTimeEqualsUtf8(computed, expectedHashBase64);
    }

    /**
     * Compares two strings in constant time using their UTF-8 byte representation.
     *
     * Notes:
     * - Length mismatch returns false immediately.
     * - If you pass empty/invalid computed hashes, validation will fail safely.
     */
    private static boolean constantTimeEqualsUtf8(String a, String b) {
        if (a == null || b == null) return false;

        byte[] aa = a.getBytes(StandardCharsets.UTF_8);
        byte[] bb = b.getBytes(StandardCharsets.UTF_8);

        if (aa.length != bb.length) return false;

        int result = 0;
        for (int i = 0; i < aa.length; i++) {
            result |= (aa[i] ^ bb[i]);
        }
        return result == 0;
    }

    /**
     * PBKDF2(PRF=HMAC, P, S, c, dkLen)
     *
     * Parameters:
     * - password: password bytes (P)
     * - salt: random salt bytes (S)
     * - iterations: iteration count (c)
     * - dkLen: desired derived key length in bytes (dkLen)
     * - hmacAlg: HMAC algorithm name (PRF), e.g. "HmacSHA256"
     */
    private static byte[] pbkdf2(byte[] password, byte[] salt, int iterations, int dkLen, String hmacAlg) throws Exception {
        // PBKDF2 uses an HMAC-based PRF. We use the password as the HMAC key.
        Mac mac = Mac.getInstance(hmacAlg);
        mac.init(new SecretKeySpec(password, hmacAlg));

        int hLen = mac.getMacLength();
        int l = (int) Math.ceil((double) dkLen / hLen);

        byte[] dk = new byte[dkLen];
        int dkOffset = 0;

        // PBKDF2 output is the concatenation of T_1 || T_2 || ... || T_l, truncated to dkLen.
        for (int i = 1; i <= l; i++) {
            byte[] block = F(mac, salt, iterations, i);

            int bytesToCopy = Math.min(hLen, dkLen - dkOffset);
            System.arraycopy(block, 0, dk, dkOffset, bytesToCopy);
            dkOffset += bytesToCopy;
        }

        return dk;
    }

    /**
     * F(P, S, c, i) = U1 xor U2 xor ... xor Uc
     *
     * Where:
     * - U1 = PRF(P, S || INT(i))
     * - Uj = PRF(P, Uj-1) for j > 1
     *
     * This is the core PBKDF2 mixing function for each block index.
     */
    private static byte[] F(Mac mac, byte[] salt, int iterations, int blockIndex) {
        // INT(i) is the 4-byte big-endian block index.
        byte[] intI = ByteBuffer.allocate(4).putInt(blockIndex).array();

        mac.reset();
        mac.update(salt);
        mac.update(intI);
        byte[] u = mac.doFinal();
        byte[] t = u.clone();

        // XOR U2..Uc into the running block value.
        for (int j = 2; j <= iterations; j++) {
            mac.reset();
            u = mac.doFinal(u);
            for (int k = 0; k < t.length; k++) {
                t[k] ^= u[k];
            }
        }

        return t;
    }
}